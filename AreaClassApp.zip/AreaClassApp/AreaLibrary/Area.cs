﻿using System;

namespace AreaLibrary
{
    //Create AreaClass
    public class AreaClass
    {     
        //Create overloaded static Area() method for finding the area of a circle and return type double.
        public static double Area(double radius)
        {
            return Math.PI * Math.Pow(radius, 2);
        }
        //Create overloaded static Area() method for finding the area of a rectangle and return type double.
        public static double Area(double length, double width)
        {
            return length * width;
        }
        //Create overloaded static Area() method for finding the area of a cylinder and return type double.
        public static double Area(double pi, double height, double radius)
        {
            return pi * Math.Pow(radius, 2) * height;
        }

    }
}
