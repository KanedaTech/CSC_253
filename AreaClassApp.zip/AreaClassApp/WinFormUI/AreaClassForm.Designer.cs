﻿
namespace WinFormUI
{
    partial class AreaClassForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CircleButton = new System.Windows.Forms.Button();
            this.RectangleButton = new System.Windows.Forms.Button();
            this.CylinderButton = new System.Windows.Forms.Button();
            this.AreaDisplayLabel = new System.Windows.Forms.Label();
            this.ShapeChoiceLabel = new System.Windows.Forms.Label();
            this.ShapeAreaDisplayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CircleButton
            // 
            this.CircleButton.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.CircleButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CircleButton.Location = new System.Drawing.Point(12, 70);
            this.CircleButton.Name = "CircleButton";
            this.CircleButton.Size = new System.Drawing.Size(131, 95);
            this.CircleButton.TabIndex = 0;
            this.CircleButton.Text = "CIRCLE";
            this.CircleButton.UseVisualStyleBackColor = false;
            this.CircleButton.Click += new System.EventHandler(this.CircleButton_Click);
            // 
            // RectangleButton
            // 
            this.RectangleButton.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.RectangleButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.RectangleButton.Location = new System.Drawing.Point(169, 70);
            this.RectangleButton.Name = "RectangleButton";
            this.RectangleButton.Size = new System.Drawing.Size(129, 95);
            this.RectangleButton.TabIndex = 0;
            this.RectangleButton.Text = "RECTANGLE";
            this.RectangleButton.UseVisualStyleBackColor = false;
            this.RectangleButton.Click += new System.EventHandler(this.RectangleButton_Click);
            // 
            // CylinderButton
            // 
            this.CylinderButton.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.CylinderButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CylinderButton.Location = new System.Drawing.Point(318, 70);
            this.CylinderButton.Name = "CylinderButton";
            this.CylinderButton.Size = new System.Drawing.Size(134, 95);
            this.CylinderButton.TabIndex = 0;
            this.CylinderButton.Text = "CYLINDER";
            this.CylinderButton.UseVisualStyleBackColor = false;
            this.CylinderButton.Click += new System.EventHandler(this.CylinderButton_Click);
            // 
            // AreaDisplayLabel
            // 
            this.AreaDisplayLabel.AutoSize = true;
            this.AreaDisplayLabel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.AreaDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AreaDisplayLabel.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AreaDisplayLabel.Location = new System.Drawing.Point(157, 265);
            this.AreaDisplayLabel.MinimumSize = new System.Drawing.Size(150, 50);
            this.AreaDisplayLabel.Name = "AreaDisplayLabel";
            this.AreaDisplayLabel.Size = new System.Drawing.Size(150, 50);
            this.AreaDisplayLabel.TabIndex = 1;
            this.AreaDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ShapeChoiceLabel
            // 
            this.ShapeChoiceLabel.AutoSize = true;
            this.ShapeChoiceLabel.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ShapeChoiceLabel.Location = new System.Drawing.Point(140, 21);
            this.ShapeChoiceLabel.Name = "ShapeChoiceLabel";
            this.ShapeChoiceLabel.Size = new System.Drawing.Size(196, 37);
            this.ShapeChoiceLabel.TabIndex = 2;
            this.ShapeChoiceLabel.Text = "Choose Shape";
            // 
            // ShapeAreaDisplayLabel
            // 
            this.ShapeAreaDisplayLabel.AutoSize = true;
            this.ShapeAreaDisplayLabel.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ShapeAreaDisplayLabel.Location = new System.Drawing.Point(191, 228);
            this.ShapeAreaDisplayLabel.Name = "ShapeAreaDisplayLabel";
            this.ShapeAreaDisplayLabel.Size = new System.Drawing.Size(84, 37);
            this.ShapeAreaDisplayLabel.TabIndex = 2;
            this.ShapeAreaDisplayLabel.Text = "Area:";
            // 
            // AreaClassForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(464, 340);
            this.Controls.Add(this.ShapeAreaDisplayLabel);
            this.Controls.Add(this.ShapeChoiceLabel);
            this.Controls.Add(this.AreaDisplayLabel);
            this.Controls.Add(this.CylinderButton);
            this.Controls.Add(this.RectangleButton);
            this.Controls.Add(this.CircleButton);
            this.Name = "AreaClassForm";
            this.Text = "Area Class Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CircleButton;
        private System.Windows.Forms.Button RectangleButton;
        private System.Windows.Forms.Button CylinderButton;
        private System.Windows.Forms.Label AreaDisplayLabel;
        private System.Windows.Forms.Label ShapeChoiceLabel;
        private System.Windows.Forms.Label ShapeAreaDisplayLabel;
    }
}

