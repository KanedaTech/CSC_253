﻿/**
* 8-31-2021
* CSC 253
* Adrian Gorum 
* Application makes use of overloaded static methods to calculate the areas of a circle, rectangle, and cylinder. 
*/
using System;
using AreaLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class AreaClassForm : Form
    {
        
        public AreaClassForm()
        {
            InitializeComponent();            
        }
        //When CircleButton is clicked, initialize a type double variable called CircleArea and assign it the value returned by calling the overloaded
        //static method Area() found in the AreaClass.
        //To find the area of the circle 1 argument is passed in the Area() method.
        private void CircleButton_Click(object sender, EventArgs e)
        {
            //Initialize type double variable and assign it the returned value from AreaClass.Area() method. Use only one argument(double radius) to retrieve the area of a circle.
            double CircleArea = AreaClass.Area(16.4);
            //Round the CircleArea value to 2 decimal places.
            CircleArea = Math.Round(CircleArea, 2);
            //Display the CircleArea value as a string in the AreaDisplayLabel.
            AreaDisplayLabel.Text = Convert.ToString(CircleArea);
        }
        //When RectangleButton is clicked, initialize a type double variable called RectangleArea and assign it the value returned by calling the overloaded
        //static method Area() found in the AreaClass.
        //To find the area of the circle 2 arguments are passed in the Area() method.
        private void RectangleButton_Click(object sender, EventArgs e)
        {
            //Initialize type double variable and assign it the returned value from AreaClass.Area() method. Use two arguments(double length, double width) to retrieve the area of a rectangle.
            double RectangleArea = AreaClass.Area(24, 7);
            //Round the RectangleArea value to 2 decimal places.
            RectangleArea = Math.Round(RectangleArea, 2);
            //Display the RectangleArea value as a string in the AreaDisplayLabel.
            AreaDisplayLabel.Text = Convert.ToString(RectangleArea);
        }
        //When CylinderButton is clicked, initialize a type double variable called CylinderArea and assign it the value returned by calling the overloaded
        //static method Area() found in the AreaClass.
        //To find the area of the circle 3 arguments are passed in the Area() method.
        private void CylinderButton_Click(object sender, EventArgs e)
        {
            //Initialize type double variable and assign it the returned value from AreaClass.Area() method. Use three arguments(double pi, double height, double radius) to retrieve the
            //area of a cylinder.
            double CylinderArea = AreaClass.Area(Math.PI, 26, 25);
            //Round the CylinderArea value to 2 decimal places.
            CylinderArea = Math.Round(CylinderArea, 2);
            //Display the CylinderArea value as a string in the AreaDisplayLabel.
            AreaDisplayLabel.Text = Convert.ToString(CylinderArea);
        }

    }
}
