﻿namespace AverageNumberOfLettersLibrary
{
    public class Average
    {
        public static double CountWords(string words)
        {
            //Initialize string array and assign it the value of the passed string argument words. Use method call Split() to separate the words in the string that was passed.
            string[] wordsArray = words.Split(' ');
            //Return the length of the array.
            return wordsArray.Length;
        }

        public static double CountChars(string words)
        {
            string[] wordsArray = words.Split(' ');

            double CharCount = 0;

            foreach(string word in wordsArray)
            {
                foreach(char x in word)
                {
                    CharCount++;
                }
                
            }

            return CharCount;
        }
    }
}
