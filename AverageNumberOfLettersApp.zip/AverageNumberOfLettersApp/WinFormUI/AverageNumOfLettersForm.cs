﻿using System;
using AverageNumberOfLettersLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class AverageNumOfLettersForm : Form
    {
        public AverageNumOfLettersForm()
        {
            InitializeComponent();
        }

        private void CalculateAverageOfCharButton_Click(object sender, EventArgs e)
        {
            string words = StringTextBox.Text.Trim();
            double wordCount = Average.CountWords(words);
            double charCount = Average.CountChars(words);
            double averageChar = Math.Round(charCount / wordCount);

            MessageBox.Show("The average number of characters in the textbox is: " + averageChar);
        }
    }
}
