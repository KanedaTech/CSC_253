﻿namespace CarModel
{
    public class Car
    {
        public string year { get; set; }
        public string make { get; set; }
        public int speed { get; set; }

        public Car(string argYear, string argMake)
        {
            year = argYear;
            make = argMake;
            speed = 0;
        }

        public int Accelerate()
        {
            return speed += 5;
        }

        public int Brake()
        {
            return speed -= 5;
        }       

    }
}
