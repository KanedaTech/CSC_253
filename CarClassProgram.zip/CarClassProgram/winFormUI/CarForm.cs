﻿using System;
using CarModel;
using System.Windows.Forms;

namespace winFormUI
{
    public partial class CarForm : Form
    {

        public CarForm()
        {
            InitializeComponent();
        }

        Car Car1 = new Car("1998", "Honda");
        public void initializeButton_Click(object sender, EventArgs e)
        {          

            CarYearLabel_2.Text = Car1.year;
            CarMakeLable_2.Text = Car1.make;
            SpeedLabel_2.Text = Convert.ToString(Car1.speed);
        }

        public void accelerateButton_Click(object sender, EventArgs e)
        {
            Car1.Accelerate();
            SpeedLabel_2.Text = Convert.ToString(Car1.speed);
        }

        public void brakeButton_Click(object sender, EventArgs e)
        {
            Car1.Brake();
            SpeedLabel_2.Text = Convert.ToString(Car1.speed);
        }
    }
}
