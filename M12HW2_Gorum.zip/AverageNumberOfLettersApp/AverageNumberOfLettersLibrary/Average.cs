﻿/**
* 9-7-2021
* CSC 253
* Adrian Gorum
* Program displays the average number of letters in each word of a given string provided by the user.
*/
namespace AverageNumberOfLettersLibrary
{
    //Create public class Average.
    public class Average
    {
        //Create public double method CountWords() that accepts one string argument.
        public static double CountWords(string words)
        {
            //Initialize string array and assign it the value of the passed string argument words. Use method call Split() to separate the words in the string that was passed.
            string[] wordsArray = words.Split(' ');
            //Return the length of the array.
            return wordsArray.Length;
        }
        //Create public double method CountChars that accepts one string argument.
        public static double CountChars(string words)
        {
            //Initialize string array and assign it the value of the passed argument words. Use method call Split() to separate the words in the string that was passed.
            string[] wordsArray = words.Split(' ');
            //Initialize variable CharCount and assign it the value of 0.
            double CharCount = 0;
            //Use a nested foreach loop to go over every word in the wordsArray and count every character of every word found in wordsArray.
            foreach(string word in wordsArray)
            {
                foreach(char x in word)
                {
                    //Increment CharCount variable by 1 on each iteration.
                    CharCount++;
                }
                
            }
            //Return CharCount
            return CharCount;
        }
    }
}
