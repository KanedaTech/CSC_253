﻿/**
* 9-7-2021
* CSC 253
* Adrian Gorum
* Program displays the average number of letters in each word of a given string provided by the user.
*/
using System;
using AverageNumberOfLettersLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class AverageNumOfLettersForm : Form
    {
        public AverageNumOfLettersForm()
        {
            InitializeComponent();
        }

        private void CalculateAverageOfCharButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable words that holds the string input from StringTextBox.
            string words = StringTextBox.Text.Trim();
            //Initialize type double variable wordCount and assign it the value returned by the method call of CountWords().
            double wordCount = Average.CountWords(words);
            //Initialize type double variable charCount and assign it the value returned by the method call of CoutChars().
            double charCount = Average.CountChars(words);
            //Initialize type double variable averageChar and assign it the value of the calculation charCount / wordCount.
            double averageChar = Math.Round(charCount / wordCount);
            //Display a message box to use that shows the average number of characters in the string they used as input.
            MessageBox.Show("The average number of characters in the textbox is: " + averageChar);
        }
    }
}
