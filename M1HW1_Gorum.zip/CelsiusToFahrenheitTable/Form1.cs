﻿/**
* 8-20-2021
* CSC 253
* Adrian Gorum
* Program displays a table of celsius temperatures (0-20) and their fahrenheit equivalents.
* Program uses a loop to display the values in a ListBox.
*/
using System;
using System.Windows.Forms;

namespace CelsiusToFahrenheitTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Initlialize variables to hold type double values to be used in a formula within for loop.
            double celsius; //holds the celsius temp
            double fahrenheit; //holds the fahrenheit temp

            //Display a header for the tabler
            temperatureListBox.Items.Add("Celsius\tFahrenheit");
            temperatureListBox.Items.Add("------------------------");

            //Usicing a for loop, displays the table of temperatures.
            for (celsius = 0; celsius <= 20; celsius++)
            {
                //Formula finds fahrenheit value based on celsius value
                fahrenheit = (9.0 / 5.0) * celsius + 32;
                
                //Convert to string to format only having one value after decimal point
                string fahString = string.Format("{0:0.0}", fahrenheit);
                
                //Displays a listbox of celsius and fahrenheit values in the form
                temperatureListBox.Items.Add(celsius + "\t" + fahString);
            }
        }
    }
}
