﻿
namespace Kinetic_Energy
{
    partial class KineticEnergyForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.velocityTextBox = new System.Windows.Forms.TextBox();
            this.enterMassTextLabel = new System.Windows.Forms.Label();
            this.enterVelocityTextLabel = new System.Windows.Forms.Label();
            this.KineticEnergyLabel = new System.Windows.Forms.Label();
            this.displayKineticEnergyLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(166, 28);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 23);
            this.massTextBox.TabIndex = 0;
            // 
            // velocityTextBox
            // 
            this.velocityTextBox.Location = new System.Drawing.Point(166, 71);
            this.velocityTextBox.Name = "velocityTextBox";
            this.velocityTextBox.Size = new System.Drawing.Size(100, 23);
            this.velocityTextBox.TabIndex = 1;
            // 
            // enterMassTextLabel
            // 
            this.enterMassTextLabel.AutoSize = true;
            this.enterMassTextLabel.Location = new System.Drawing.Point(26, 31);
            this.enterMassTextLabel.Name = "enterMassTextLabel";
            this.enterMassTextLabel.Size = new System.Drawing.Size(134, 15);
            this.enterMassTextLabel.TabIndex = 2;
            this.enterMassTextLabel.Text = "Enter the object\'s mass: ";
            // 
            // enterVelocityTextLabel
            // 
            this.enterVelocityTextLabel.AutoSize = true;
            this.enterVelocityTextLabel.Location = new System.Drawing.Point(12, 74);
            this.enterVelocityTextLabel.Name = "enterVelocityTextLabel";
            this.enterVelocityTextLabel.Size = new System.Drawing.Size(148, 15);
            this.enterVelocityTextLabel.TabIndex = 3;
            this.enterVelocityTextLabel.Text = "Enter the object\'s velocity: ";
            // 
            // KineticEnergyLabel
            // 
            this.KineticEnergyLabel.AutoSize = true;
            this.KineticEnergyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.KineticEnergyLabel.Location = new System.Drawing.Point(166, 112);
            this.KineticEnergyLabel.MaximumSize = new System.Drawing.Size(100, 23);
            this.KineticEnergyLabel.MinimumSize = new System.Drawing.Size(100, 23);
            this.KineticEnergyLabel.Name = "KineticEnergyLabel";
            this.KineticEnergyLabel.Size = new System.Drawing.Size(100, 23);
            this.KineticEnergyLabel.TabIndex = 4;
            // 
            // displayKineticEnergyLabel
            // 
            this.displayKineticEnergyLabel.AutoSize = true;
            this.displayKineticEnergyLabel.Location = new System.Drawing.Point(72, 112);
            this.displayKineticEnergyLabel.Name = "displayKineticEnergyLabel";
            this.displayKineticEnergyLabel.Size = new System.Drawing.Size(88, 15);
            this.displayKineticEnergyLabel.TabIndex = 5;
            this.displayKineticEnergyLabel.Text = "Kinetic energy: ";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(46, 169);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(91, 42);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate Kinetic Energy";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(166, 169);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(91, 42);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // KineticEnergyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 233);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.displayKineticEnergyLabel);
            this.Controls.Add(this.KineticEnergyLabel);
            this.Controls.Add(this.enterVelocityTextLabel);
            this.Controls.Add(this.enterMassTextLabel);
            this.Controls.Add(this.velocityTextBox);
            this.Controls.Add(this.massTextBox);
            this.Name = "KineticEnergyForm";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.TextBox velocityTextBox;
        private System.Windows.Forms.Label enterMassTextLabel;
        private System.Windows.Forms.Label enterVelocityTextLabel;
        private System.Windows.Forms.Label KineticEnergyLabel;
        private System.Windows.Forms.Label displayKineticEnergyLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

