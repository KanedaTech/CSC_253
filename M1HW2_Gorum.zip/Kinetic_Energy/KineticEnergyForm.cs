﻿/**
* 8-20-2021
* CSC 253
* Adrian Gorum
* Winform application uses method to calculate the mass and velocity 
* a user enters and displays the kinetic energy created.
*/
using System;
using System.Windows.Forms;

namespace Kinetic_Energy
{
    public partial class KineticEnergyForm : Form
    {
        public KineticEnergyForm()
        {
            InitializeComponent();
        }

        //KineticEnergy method accepts two arguments(mass value and velocity value) and returns a double value
        private double KineticEnergy(double mass, double velocity)
        {
            return 0.5 * mass * Math.Pow(velocity, 2.0);
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Initialize type double variables to hold values for mass, velocity, and energy
            double mass, velocity, energy;

            //Get mass value
            if (double.TryParse(massTextBox.Text, out mass))
            {
                //Get velocity value
                if (double.TryParse(velocityTextBox.Text, out velocity))
                {
                    //Set energy value by using a method call of KineticEnergy(arg1, arg2)
                    energy = KineticEnergy(mass, velocity);

                    //Display kinetic energy value in label
                    KineticEnergyLabel.Text = energy.ToString("n1");
                }
                else
                {
                    //Display a message to the user if invalid data is entered into the velocityTextBox
                    MessageBox.Show("Velocity is invalid.");
                }
            }
            else
            {
                //Display a message to the user if invalid data is entered into the massTextBox
                MessageBox.Show("Mass is invalid.");
            }
         }

        
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application if exitButton is clicked
            Close();
        }
    }
}
