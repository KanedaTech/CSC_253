﻿/**
* 8-31-2021
* CSC 253
* Adrian Gorum
* Application generates a car object and displays the year, make and speed of the car object. 
* User will be able to utilize an "accelerate" button and a "brake" button to change the speed value of the car object.
*/
namespace CarModel
{
    //Create class Car.
    public class Car
    {
        //Assign class properties for Car class; Year, Make, & Speed.
        public string Year { get; set; }
        public string Make { get; set; }
        public int Speed { get; set; }
        //Create class contructor for Car class that accepts two arguments for the Year and Make.
        public Car(string argYear, string argMake)
        {
            //Assign Class Properties the values of passed arguments. Assign a default value of 0 to the Speed property.
            Year = argYear;
            Make = argMake;
            Speed = 0;
        }
        //Create Accelerate() method that returns type int incrementing the current Speed property value by 5.
        public int Accelerate()
        {
            return Speed += 5;
        }
        //Create Brake() method that returns type int decreasing the current Speed property value by 5.
        public int Brake()
        {
            return Speed -= 5;
        }       

    }
}
