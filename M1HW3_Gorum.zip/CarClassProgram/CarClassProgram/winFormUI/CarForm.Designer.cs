﻿
namespace winFormUI
{
    partial class CarForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.carMakeLabel = new System.Windows.Forms.Label();
            this.carYearLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.brakeButton = new System.Windows.Forms.Button();
            this.CarYearLabel_2 = new System.Windows.Forms.Label();
            this.CarMakeLable_2 = new System.Windows.Forms.Label();
            this.SpeedLabel_2 = new System.Windows.Forms.Label();
            this.initializeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // carMakeLabel
            // 
            this.carMakeLabel.AutoSize = true;
            this.carMakeLabel.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.carMakeLabel.Location = new System.Drawing.Point(210, 267);
            this.carMakeLabel.Name = "carMakeLabel";
            this.carMakeLabel.Size = new System.Drawing.Size(173, 45);
            this.carMakeLabel.TabIndex = 0;
            this.carMakeLabel.Text = "Car Make: ";
            // 
            // carYearLabel
            // 
            this.carYearLabel.AutoSize = true;
            this.carYearLabel.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.carYearLabel.Location = new System.Drawing.Point(230, 199);
            this.carYearLabel.Name = "carYearLabel";
            this.carYearLabel.Size = new System.Drawing.Size(153, 45);
            this.carYearLabel.TabIndex = 1;
            this.carYearLabel.Text = "Car Year: ";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.speedLabel.Location = new System.Drawing.Point(257, 331);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(126, 45);
            this.speedLabel.TabIndex = 2;
            this.speedLabel.Text = "Speed: ";
            // 
            // accelerateButton
            // 
            this.accelerateButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.accelerateButton.Location = new System.Drawing.Point(110, 453);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(227, 143);
            this.accelerateButton.TabIndex = 4;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.AccelerateButton_Click);
            // 
            // brakeButton
            // 
            this.brakeButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.brakeButton.Location = new System.Drawing.Point(426, 453);
            this.brakeButton.Name = "brakeButton";
            this.brakeButton.Size = new System.Drawing.Size(227, 143);
            this.brakeButton.TabIndex = 4;
            this.brakeButton.Text = "Brake";
            this.brakeButton.UseVisualStyleBackColor = true;
            this.brakeButton.Click += new System.EventHandler(this.BrakeButton_Click);
            // 
            // CarYearLabel_2
            // 
            this.CarYearLabel_2.AutoSize = true;
            this.CarYearLabel_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CarYearLabel_2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CarYearLabel_2.Location = new System.Drawing.Point(399, 199);
            this.CarYearLabel_2.MinimumSize = new System.Drawing.Size(130, 50);
            this.CarYearLabel_2.Name = "CarYearLabel_2";
            this.CarYearLabel_2.Size = new System.Drawing.Size(130, 50);
            this.CarYearLabel_2.TabIndex = 5;
            // 
            // CarMakeLable_2
            // 
            this.CarMakeLable_2.AutoSize = true;
            this.CarMakeLable_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CarMakeLable_2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CarMakeLable_2.Location = new System.Drawing.Point(399, 265);
            this.CarMakeLable_2.MinimumSize = new System.Drawing.Size(130, 50);
            this.CarMakeLable_2.Name = "CarMakeLable_2";
            this.CarMakeLable_2.Size = new System.Drawing.Size(130, 50);
            this.CarMakeLable_2.TabIndex = 5;
            // 
            // SpeedLabel_2
            // 
            this.SpeedLabel_2.AutoSize = true;
            this.SpeedLabel_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SpeedLabel_2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SpeedLabel_2.Location = new System.Drawing.Point(399, 329);
            this.SpeedLabel_2.MinimumSize = new System.Drawing.Size(130, 50);
            this.SpeedLabel_2.Name = "SpeedLabel_2";
            this.SpeedLabel_2.Size = new System.Drawing.Size(130, 50);
            this.SpeedLabel_2.TabIndex = 5;
            // 
            // initializeButton
            // 
            this.initializeButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.initializeButton.Location = new System.Drawing.Point(257, 50);
            this.initializeButton.Name = "initializeButton";
            this.initializeButton.Size = new System.Drawing.Size(255, 77);
            this.initializeButton.TabIndex = 6;
            this.initializeButton.Text = "Generate Car";
            this.initializeButton.UseVisualStyleBackColor = true;
            this.initializeButton.Click += new System.EventHandler(this.InitializeButton_Click);
            // 
            // CarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 764);
            this.Controls.Add(this.initializeButton);
            this.Controls.Add(this.SpeedLabel_2);
            this.Controls.Add(this.CarMakeLable_2);
            this.Controls.Add(this.CarYearLabel_2);
            this.Controls.Add(this.brakeButton);
            this.Controls.Add(this.accelerateButton);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.carYearLabel);
            this.Controls.Add(this.carMakeLabel);
            this.Name = "CarForm";
            this.Text = "Car Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label carMakeLabel;
        private System.Windows.Forms.Label carYearLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button brakeButton;
        private System.Windows.Forms.Label CarYearLabel_2;
        private System.Windows.Forms.Label CarMakeLable_2;
        private System.Windows.Forms.Label SpeedLabel_2;
        private System.Windows.Forms.Button initializeButton;
    }
}

