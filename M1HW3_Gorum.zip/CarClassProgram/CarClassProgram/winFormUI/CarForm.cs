﻿/**
* 8-31-2021
* CSC 253
* Adrian Gorum
* Application generates a car object and displays the year, make and speed of the car object. 
* User will be able to utilize an "accelerate" button and a "brake" button to change the speed value of the car object.
*/
using System;
using CarModel;
using System.Windows.Forms;

namespace winFormUI
{
    public partial class CarForm : Form
    {

        public CarForm()
        {
            InitializeComponent();
        }
        //Create Car object from CarModel class library and assign year and make property values.
        Car Car1 = new Car("1998", "Honda");

        //When "Generate Car"/InitializeButton is clicked, display assigned object properties in CarYearLabel, CarMakeLabel and SpeedLabel.
        public void InitializeButton_Click(object sender, EventArgs e)
        {          

            CarYearLabel_2.Text = Car1.Year;
            CarMakeLable_2.Text = Car1.Make;
            SpeedLabel_2.Text = Convert.ToString(Car1.Speed);
        }
        //When AccelerateButton is clicked, call Accelerate() method from CarModel library to increase the speed property value by 5.
        public void AccelerateButton_Click(object sender, EventArgs e)
        {
            //Call Accelerate() method.
            Car1.Accelerate();
            //Display Speed property value of Car1 object in SpeedLabel_2
            SpeedLabel_2.Text = Convert.ToString(Car1.Speed);
        }
        //When BrakeButton is clicked, call Brake() method from CarModel library to decrease the speed property value by 5.
        public void BrakeButton_Click(object sender, EventArgs e)
        {
            //Call Brake() method.
            Car1.Brake();
            //Display Speed property value of Car1 object in SpeedLabel_2.
            SpeedLabel_2.Text = Convert.ToString(Car1.Speed);
        }
    }
}
