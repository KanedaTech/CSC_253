﻿/**
* 9/09/2021
* CSC 253
* Adrian Gorum
* Application allows the user to enter a string and displays the character 
* that appears most frequently in inputed string.
*/
namespace FrequentCharLibrary
{
    //Creat a public class FreqChar
    public class FreqChar
    {
        //Create a public char method that takes a string argument.
        public static char MostFrequent(string userInput)
        {
            //Initialize a new integer array and assign it the value of 256
            int[] charCnt = new int[256];
            //Initialize an int variable and assign it the value of the length of the argument passed to the method.
            int usrInputLen = userInput.Length;
            //Use a for loop to count the number of characters in the string the user inputed.
            for (int i = 0; i < usrInputLen; i++)
            {
                //Increments the array index by 1 each iteration.
                charCnt[userInput[i]]++;
            }
            //Initialize a max count variable type int. Assign it a value of -1.
            int maxCnt = -1;
            //Initialize character variable type char. Assign it a value of whitespace.
            char character = ' ';
            //Use a for loop to iterate over the length of the user's input.
            for (int i = 0; i < usrInputLen; i++)
            {
                //If statement check is max count is less than the amount of indecies in charCnt array.
                if (maxCnt < charCnt[userInput[i]])
                {
                    //Assign maxCnt variable the index value of the charCnt array.
                    maxCnt = charCnt[userInput[i]];
                    //Assign character value the char value from userInput variable index.
                    character = userInput[i];
                }
            }
            //Return character variable.
            return character;
        }        
    }
}
