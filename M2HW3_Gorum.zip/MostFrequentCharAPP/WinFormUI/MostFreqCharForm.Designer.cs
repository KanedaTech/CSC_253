﻿
namespace WinFormUI
{
    partial class MostFreqCharForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StringTextBox = new System.Windows.Forms.TextBox();
            this.EnterStringLabel = new System.Windows.Forms.Label();
            this.MostFrequentButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StringTextBox
            // 
            this.StringTextBox.Location = new System.Drawing.Point(12, 79);
            this.StringTextBox.Name = "StringTextBox";
            this.StringTextBox.Size = new System.Drawing.Size(293, 23);
            this.StringTextBox.TabIndex = 0;
            // 
            // EnterStringLabel
            // 
            this.EnterStringLabel.AutoSize = true;
            this.EnterStringLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EnterStringLabel.Location = new System.Drawing.Point(84, 39);
            this.EnterStringLabel.Name = "EnterStringLabel";
            this.EnterStringLabel.Size = new System.Drawing.Size(151, 21);
            this.EnterStringLabel.TabIndex = 1;
            this.EnterStringLabel.Text = "Enter String Below";
            // 
            // MostFrequentButton
            // 
            this.MostFrequentButton.BackColor = System.Drawing.SystemColors.Info;
            this.MostFrequentButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MostFrequentButton.Location = new System.Drawing.Point(63, 127);
            this.MostFrequentButton.Name = "MostFrequentButton";
            this.MostFrequentButton.Size = new System.Drawing.Size(187, 79);
            this.MostFrequentButton.TabIndex = 2;
            this.MostFrequentButton.Text = "Find Most Frequent Character";
            this.MostFrequentButton.UseVisualStyleBackColor = false;
            this.MostFrequentButton.Click += new System.EventHandler(this.MostFrequentButton_Click);
            // 
            // MostFreqCharForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(317, 236);
            this.Controls.Add(this.MostFrequentButton);
            this.Controls.Add(this.EnterStringLabel);
            this.Controls.Add(this.StringTextBox);
            this.Name = "MostFreqCharForm";
            this.Text = "Most Frequent Character App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox StringTextBox;
        private System.Windows.Forms.Label EnterStringLabel;
        private System.Windows.Forms.Button MostFrequentButton;
    }
}

