﻿/**
* 9/09/2021
* CSC 253
* Adrian Gorum
* Application allows the user to enter a string and displays the character 
* that appears most frequently in inputed string.
*/
using System;
using FrequentCharLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class MostFreqCharForm : Form
    {
        public MostFreqCharForm()
        {
            InitializeComponent();
        }

        private void MostFrequentButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable usrInput to hold string value inputed by user.
            string usrInput = StringTextBox.Text.Trim();
            //Initialize string variable newStr and assign it usrInput and remove all spaces.
            string newStr = usrInput.Replace(" ", String.Empty);
            //Initialize char variable freqChar and assign it the returned value from the method call MostFrequent().
            char freqChar = FreqChar.MostFrequent(newStr);
            //Display a message to the use that shows the most frequent character used in the string they entered. Capitalize the character.
            MessageBox.Show("The most frequent character from the string entered is: " + Char.ToUpper(freqChar));

        }
    }
}
