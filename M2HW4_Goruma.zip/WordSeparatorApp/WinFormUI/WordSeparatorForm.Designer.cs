﻿
namespace WinFormUI
{
    partial class WordSeparatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WordSeparatorButton = new System.Windows.Forms.Button();
            this.UserStringTextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // WordSeparatorButton
            // 
            this.WordSeparatorButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.WordSeparatorButton.Location = new System.Drawing.Point(140, 85);
            this.WordSeparatorButton.Name = "WordSeparatorButton";
            this.WordSeparatorButton.Size = new System.Drawing.Size(142, 71);
            this.WordSeparatorButton.TabIndex = 0;
            this.WordSeparatorButton.Text = "Separate Words";
            this.WordSeparatorButton.UseVisualStyleBackColor = true;
            this.WordSeparatorButton.Click += new System.EventHandler(this.WordSeparatorButton_Click);
            // 
            // UserStringTextbox
            // 
            this.UserStringTextbox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UserStringTextbox.Location = new System.Drawing.Point(12, 50);
            this.UserStringTextbox.Name = "UserStringTextbox";
            this.UserStringTextbox.Size = new System.Drawing.Size(430, 29);
            this.UserStringTextbox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(88, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 44);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter a string with no spaces and every world capitalized below.";
            // 
            // WordSeparatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 168);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserStringTextbox);
            this.Controls.Add(this.WordSeparatorButton);
            this.Name = "WordSeparatorForm";
            this.Text = "Word Separator App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button WordSeparatorButton;
        private System.Windows.Forms.TextBox UserStringTextbox;
        private System.Windows.Forms.Label label1;
    }
}

