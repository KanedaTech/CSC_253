﻿/**
* 9/10/2021
* CSC 253
* Adrian Gorum
* Application accepts as input a string from the user where all words are run together and uppercase then
* converts the string to one which has it's words separated by spaces and capitalizes only the first word in the string.
*/
using System;
using WordSeparatorLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class WordSeparatorForm : Form
    {
        public WordSeparatorForm()
        {
            InitializeComponent();
        }

        private void WordSeparatorButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable and assign UserStringTextbox.Text as the value.
            string usrInput = UserStringTextbox.Text;
            //Initialize string variable and assign the value returned from the SeparatedString() method call from Separator class.
            string separatedString = Separator.SeparatedString(usrInput);
            //Display message box to user showing their input separated and the first word capitalized.
            MessageBox.Show("This is your string separated:" + "\n" + "\n" + Char.ToUpper(separatedString[0]) + separatedString[1..]);
        }
    }
}
