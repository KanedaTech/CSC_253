﻿/**
* 9/10/2021
* CSC 253
* Adrian Gorum
* Application accepts as input a string from the user where all words are run together and uppercase then
* converts the string to one which has it's words separated by spaces and capitalizes only the first word in the string.
*/
using System;
using System.Text;

namespace WordSeparatorLibrary
{
    //Define class Separator
    public class Separator
    {
        //Create public string method that takes a string value as an argument.
        public static string SeparatedString(string usrInput)
        {
            //Initialize variable and assign it the value of the argument passed to the method.
            string separatedStr = usrInput;
            //Initialize a new StringBuilder object.
            StringBuilder builder = new();
            //Use foreach loop to build a string from the char values found in the separatedStr variable. 
            foreach (char character in separatedStr)
            {
                //If statement checks if the individual char value is uppercase and if the builder object's length is greater than 0 then appends whitespace in between
                //each word, as well as, makes all characters lowercase.
                if (Char.IsUpper(character) && builder.Length > 0) builder.Append(' ');
                builder.Append(Char.ToLower(character));
            }
            //Assign separatedStr variable the builder object converted into a string data type.
            separatedStr = builder.ToString();
            //Method returns string variable separatedStr.
            return separatedStr;
        }
    }
}
