﻿/**
* 09-17-21
* CSC 253
* Adrian Gorum
* Application writes a series of random numbers to a file.
*/
using System;
using RandomNumWriteLibrary;
using System.Windows.Forms;
using System.Collections.Generic;

namespace WinFormUI
{
    public partial class RandomNumWriterForm : Form
    {
        public RandomNumWriterForm()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            //Initialize variable type int num and assign it the value 0.
            int num = 0;
            //Initialize a new list, data type int.
            var numList = new List<int>();
            //Initialize int variable and assign it the converted string value from the UserInputTextBox.
            int instances = Convert.ToInt32(UserInputTextBox.Text.Trim());
            //Create a new random object.
            Random random = new Random();
            //For loop iterates as long as int variable is less that the value in instances.
            for (int i = 0; i < instances; i++)
            {
                //Assign num a random number using the method call Next().
                num = random.Next(0, 100);
                //Add the random number to the numList using method call Add().
                numList.Add(num);
            }
            //Initialize a string variable message and assign it the returned value from Writer.WriteFile() method call.
            string message = Writer.WriteFile(numList);
            //Display a message to the user.
            MessageBox.Show(message);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Close the application with a Close() method call.
            Close();
        }
    }
}
