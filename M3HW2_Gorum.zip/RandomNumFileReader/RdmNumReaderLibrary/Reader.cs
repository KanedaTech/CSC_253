﻿/**
* 09-20-21
* CSC 253
* Adrian Gorum
* Application reads from a created txt file and displays the total sum of the numbers and the number of random numbers read from the file.
*/
using System;
using System.IO;
using System.Collections.Generic;

namespace RdmNumReaderLibrary
{
    public class Reader
    {
        public static List<int> ReadFile()
        {
            //Create StreamReader object inputFile and assign it a text file
            StreamReader inputFile = new StreamReader("RandomNumbers.txt");
            //Initialize string variable line
            string line;
            //Initialize List type int 
            List<int> numList = new List<int>();
            //While loop iterates over inputfile line by line as long as the line does not equal zero
            while((line = inputFile.ReadLine()) != null)
            {
                //Add the value assigned to line to the list after converting the string to type int
                numList.Add(Convert.ToInt32(line));
            }      

            //Return message string variable
            return numList;

        }
        public static string Message()
        {
            //Initialize a string variable and assign it a message for the user that an error occured.
            string message = Convert.ToString("There was an error...");

            //Return message string variable.
            return message;
        }
    }
}
