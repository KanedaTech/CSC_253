﻿
namespace WinFormUI
{
    partial class ReadFileForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberListbox = new System.Windows.Forms.ListBox();
            this.DisplayTotalLabel = new System.Windows.Forms.Label();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.ReadFileButton = new System.Windows.Forms.Button();
            this.NumAmntLabel = new System.Windows.Forms.Label();
            this.DisplayNumAmountLabel = new System.Windows.Forms.Label();
            this.QuitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NumberListbox
            // 
            this.NumberListbox.FormattingEnabled = true;
            this.NumberListbox.ItemHeight = 15;
            this.NumberListbox.Location = new System.Drawing.Point(85, 149);
            this.NumberListbox.Name = "NumberListbox";
            this.NumberListbox.Size = new System.Drawing.Size(120, 214);
            this.NumberListbox.TabIndex = 0;
            // 
            // DisplayTotalLabel
            // 
            this.DisplayTotalLabel.AutoSize = true;
            this.DisplayTotalLabel.Location = new System.Drawing.Point(40, 425);
            this.DisplayTotalLabel.Name = "DisplayTotalLabel";
            this.DisplayTotalLabel.Size = new System.Drawing.Size(45, 15);
            this.DisplayTotalLabel.TabIndex = 1;
            this.DisplayTotalLabel.Text = "TOTAL: ";
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalLabel.Location = new System.Drawing.Point(85, 420);
            this.TotalLabel.MinimumSize = new System.Drawing.Size(120, 20);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(120, 20);
            this.TotalLabel.TabIndex = 1;
            // 
            // ReadFileButton
            // 
            this.ReadFileButton.Location = new System.Drawing.Point(66, 50);
            this.ReadFileButton.Name = "ReadFileButton";
            this.ReadFileButton.Size = new System.Drawing.Size(156, 65);
            this.ReadFileButton.TabIndex = 2;
            this.ReadFileButton.Text = "Read File";
            this.ReadFileButton.UseVisualStyleBackColor = true;
            this.ReadFileButton.Click += new System.EventHandler(this.ReadFileButton_Click);
            // 
            // NumAmntLabel
            // 
            this.NumAmntLabel.Location = new System.Drawing.Point(12, 373);
            this.NumAmntLabel.Name = "NumAmntLabel";
            this.NumAmntLabel.Size = new System.Drawing.Size(73, 47);
            this.NumAmntLabel.TabIndex = 1;
            this.NumAmntLabel.Text = "Amount of numbers: ";
            // 
            // DisplayNumAmountLabel
            // 
            this.DisplayNumAmountLabel.AutoSize = true;
            this.DisplayNumAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DisplayNumAmountLabel.Location = new System.Drawing.Point(85, 383);
            this.DisplayNumAmountLabel.MinimumSize = new System.Drawing.Size(120, 20);
            this.DisplayNumAmountLabel.Name = "DisplayNumAmountLabel";
            this.DisplayNumAmountLabel.Size = new System.Drawing.Size(120, 20);
            this.DisplayNumAmountLabel.TabIndex = 1;
            // 
            // QuitButton
            // 
            this.QuitButton.Location = new System.Drawing.Point(96, 468);
            this.QuitButton.Name = "QuitButton";
            this.QuitButton.Size = new System.Drawing.Size(75, 35);
            this.QuitButton.TabIndex = 3;
            this.QuitButton.Text = "Quit";
            this.QuitButton.UseVisualStyleBackColor = true;
            this.QuitButton.Click += new System.EventHandler(this.QuitButton_Click);
            // 
            // ReadFileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 525);
            this.Controls.Add(this.QuitButton);
            this.Controls.Add(this.ReadFileButton);
            this.Controls.Add(this.DisplayNumAmountLabel);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.NumAmntLabel);
            this.Controls.Add(this.DisplayTotalLabel);
            this.Controls.Add(this.NumberListbox);
            this.Name = "ReadFileForm";
            this.Text = "Random Number Reader App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox NumberListbox;
        private System.Windows.Forms.Label DisplayTotalLabel;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.Button ReadFileButton;
        private System.Windows.Forms.Label NumAmntLabel;
        private System.Windows.Forms.Label DisplayNumAmountLabel;
        private System.Windows.Forms.Button QuitButton;
    }
}

