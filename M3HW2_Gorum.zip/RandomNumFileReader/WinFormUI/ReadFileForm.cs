﻿/**
* 09-20-21
* CSC 253
* Adrian Gorum
* Application reads from a created txt file and displays the total sum of the numbers and the number of random numbers read from the file.
*/
using System;
using System.Collections.Generic;
using RdmNumReaderLibrary;
using System.Linq;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class ReadFileForm : Form
    {
        public ReadFileForm()
        {
            InitializeComponent();
        }

        private void ReadFileButton_Click(object sender, EventArgs e)
        {
            //Initialize List variable and assign it the value returned by the Reader.ReadFile() method call.
            List<int> numList = Reader.ReadFile();
            //Initialize int variable total and assign it the value of numList.Sum() method call.
            int total = numList.Sum();
            //If statement checks if the list is empty.
            if (total == 0)
            {
                //If list is empty call Reader.Message() method.
                Reader.Message();
            }
            else
            {
                //Display the items in numList. 
                NumberListbox.DataSource = numList;
                //Display the total of the values read from the text file in the TotalLabel.
                TotalLabel.Text = Convert.ToString(total);
                //Display the amount of numbers read from file.
                DisplayNumAmountLabel.Text = Convert.ToString(numList.Count());
            }            
        }

        private void QuitButton_Click(object sender, EventArgs e)
        {
            //Close application with Close() method call.
            Close();
        }
    }
}
