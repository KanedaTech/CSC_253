﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridViewClassLibrary
{
    class DataGridViewControl
    {
        public void ChangeHeaderStyle()
        {
            dataGridView = employeeData;

            // Set the column header style.
            employeeData columnHeaderStyle =
                new DataGridViewCellStyle();
            columnHeaderStyle.BackColor = Color.Aqua;
            columnHeaderStyle.Font =
                new Font("Verdana", 10, FontStyle.Bold);
            dataGridView.ColumnHeadersDefaultCellStyle =
                columnHeaderStyle;
        }
        
    }
}
