﻿/**
* 10/4/2021
* CSC 253
* Adrian Gorum
* Application creates Personnel.mdf database with a table named Employee with 4 columns. EmployeeID is designated as the primary key. Hardcoded 5 sample rows of data and created a form
* that displays the Employee table in a DataGridView control.
*/
using System;
using System.Windows.Forms;

namespace WindowsFormUI
{
    public partial class PersonnelDatabaseForm : Form
    {
        public PersonnelDatabaseForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void PersonnelDatabaseForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }
    }
}
