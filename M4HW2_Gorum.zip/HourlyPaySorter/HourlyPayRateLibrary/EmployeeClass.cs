﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HourlyPayRateLibrary
{
    class EmployeeClass
    {
        private object employeeTableAdapter;
        private object employeeDataSet;

        public void EmployeeHourlyRateAsc()
        {
            object p = this.employeeTableAdapter.FillByHourlyPayRateAsc(employeeDataSet.Employee);
        }
    }
}
