﻿/**
* 10/4/2021
* CSC 253
* Adrian Gorum
* Program allows user to sort a dataset using buttons in a form by either ascending or descending order.
*/
using System;
using System.Windows.Forms;

namespace WindowsFormUI
{
    public partial class HourlyPayRateForm : Form
    {
        public HourlyPayRateForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void HourlyPayRateForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }
        //On HourlyPayRateAscButton_Click the application will sort the data from the Personnel.mdf database in ascending order.
        private void HourlyPayRateAscButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByHourlyPayRateAsc(this.employeeDataSet.Employee);
        }
        //On HourlyPayRateDescButton_Click the application will sort the data from the Personnel.mdf database in descending order.
        private void HourlyPayRateDescButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByHourlyPayRateDesc(this.employeeDataSet.Employee);
        }        
    }
}
