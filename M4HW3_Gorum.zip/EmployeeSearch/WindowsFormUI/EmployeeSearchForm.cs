﻿/**
* 10/11/2021
* CSC 253
* Adrian Gorum
* Application connects to Personnel.mdf database and allows the user to search for employee's based on a specified name.
*/
using System;
using System.Windows.Forms;

namespace WindowsFormUI
{
    public partial class EmployeeSearchForm : Form
    {
        public EmployeeSearchForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }
        //Method handles the employeeSearchButton click event and calls the SearchEmployee method containing the sql statement for employee search.
        private void employeeSearchButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.SearchEmployee(this.personnelDataSet.Employee, userInputTextBox.Text);
        }
        //Method handles the showAllButton click event and calls the Fill method of the employeeTableAdapter to show all employees in the dataset.
        private void showAllButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }
    }
}
