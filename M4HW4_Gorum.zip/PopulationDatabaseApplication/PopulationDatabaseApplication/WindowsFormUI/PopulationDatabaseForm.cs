﻿/**
* 10/11/21
* CSC 253
* Adrian Gorum
* Application connects to the PopulationDB.mdf database and allows the user to perform a number of functions on the database and save any changes made to the database.
*/
using System;
using System.Windows.Forms;

namespace WindowsFormUI
{
    public partial class PopulationDatabaseForm : Form
    {
        public PopulationDatabaseForm()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDataSet);

        }

        private void PopulationDatabaseForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDataSet.City);

        }
        //Method handles the saveButton click event and calls the Update method of the cityTableAdapter to save all chagnes made to the dataset/database.
        private void saveButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Update(populationDataSet.City);
        }
        //Method handles the sortAscendingButton click event and calls the sortAsc() method of the cityTableAdapter to sort the data in the table in ascending order by population in the dataset/database.

        private void sortAscendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.sortAsc(populationDataSet.City);
        }
        //Method handles the sortDescendingButton click event and calls the sortDesc() method of the cityTableAdapter to sort the data in the table in descending order by population in the dataset/database.
        private void sortDescendingButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.sortDesc(populationDataSet.City);
        }
        //Method handles the citySortButton click event and calls the sortCityName() method of the cityTableAdapter to sort the data in the table by the name of the cities in the dataset/database.
        private void citySortButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.sortCityName(populationDataSet.City);
        }
        //Method handles the totalPopulationSumButton click event and calls the totalPopulation() method of the cityTableAdapter to return the sum of all the populations in all the cities in the dataset/database.
        private void totalPopulationSumButton_Click(object sender, EventArgs e)
        {
            //Initialize type float variable total.
            float total;
            //Assign total variable the returned value from the totalPopulation() method call.
            total = (float)this.cityTableAdapter.totalPopulation();
            //Display a message to the user.
            MessageBox.Show("The total population of all cities is: " + total.ToString("N"));
        }
        //Method handles the avgPopulationButton click event and calls the avgPopulation() method of the cityTableAdapter to return the average of all the populations in all the cities in the dataset/database.
        private void avgPopulationButton_Click(object sender, EventArgs e)
        {
            //Initialize type float variable avg.
            float avg;
            //Assign total variable the returned value from the avgPopulation() method call.
            avg = (float)this.cityTableAdapter.avgPopulation();
            //Display a message to the user.
            MessageBox.Show("The average population of all cities is: " + avg.ToString("N"));
        }
        //Method handles the maxPopulationButton click event and calls the maxPopulation() method of the cityTableAdapter to return the maximum number of all the populations in all the cities in the dataset/database.
        private void maxPopulationButton_Click(object sender, EventArgs e)
        {
            //Initialize type float variable max.
            float max;
            //Assign total variable the returned value from the maxPopulation() method call.
            max = (float)this.cityTableAdapter.maxPopulation();
            //Display a message to the user.
            MessageBox.Show("The maximum population of all cities is: " + max.ToString("N"));
        }
        //Method handles the minPopulationButton click event and calls the minPopulation() method of the cityTableAdapter to return the minimum number of all the populations in all the cities in the dataset/database.
        private void minPopulationButton_Click(object sender, EventArgs e)
        {
            //Initialize type float variable min.
            float min;
            //Assign total variable the returned value from the minPopulation() method call.
            min = (float)this.cityTableAdapter.minPopulation();
            //Display a message to the user.
            MessageBox.Show("The minimum population of all cities is: " + min.ToString("N"));
        }
    }
}
