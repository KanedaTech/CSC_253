﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program allows user to enter information into a form about an employee and displays this information back to the user. Program utilizes inheritance of classes Employee class and ProductionWorker class.
*/
namespace EmployeeAndProductionWorkerClassLibrary
{
    public class Employee
    {
        //Initialize properties for Employee class.
        public string EmployeeName { get; set; }
        public int EmployeeNumber { get; set; }
        //Create Default Constructor for Employee class.
        public Employee()
        {
            EmployeeName = "Raw Meat";
            EmployeeNumber = 5432;
        }
    }
}
