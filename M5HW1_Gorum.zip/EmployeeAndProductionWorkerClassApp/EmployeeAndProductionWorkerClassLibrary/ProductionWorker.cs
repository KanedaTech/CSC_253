﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program allows user to enter information into a form about an employee and displays this information back to the user. Program utilizes inheritance of classes Employee class and ProductionWorker class.
*/
namespace EmployeeAndProductionWorkerClassLibrary
{
    //ProductionWorker inherites properties from Employee class.
    public class ProductionWorker : Employee
    {
        //Initialize ProductionWorker class properties.
        public int ShiftNumber { get; set; }
        public decimal HourlyPayRate { get; set; }
        //Create Default Constructor for ProductionWorker class.
        public ProductionWorker()
        {
            ShiftNumber = 1;
            HourlyPayRate = 25.50m;
        }
    }
}
