﻿
namespace WinFormUI
{
    partial class EmployeeAndProductionWorkerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.shiftNumberGroupBox = new System.Windows.Forms.GroupBox();
            this.nightRadioButton = new System.Windows.Forms.RadioButton();
            this.dayRadioButton = new System.Windows.Forms.RadioButton();
            this.hourlyPayRateLabel = new System.Windows.Forms.Label();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayRateTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.shiftNumberGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.AutoSize = true;
            this.employeeNameLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.employeeNameLabel.Location = new System.Drawing.Point(22, 20);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(104, 15);
            this.employeeNameLabel.TabIndex = 0;
            this.employeeNameLabel.Text = "Employee Name: ";
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.AutoSize = true;
            this.employeeNumberLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.employeeNumberLabel.Location = new System.Drawing.Point(22, 50);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(119, 15);
            this.employeeNumberLabel.TabIndex = 0;
            this.employeeNumberLabel.Text = "Employee Number:  ";
            // 
            // shiftNumberGroupBox
            // 
            this.shiftNumberGroupBox.Controls.Add(this.nightRadioButton);
            this.shiftNumberGroupBox.Controls.Add(this.dayRadioButton);
            this.shiftNumberGroupBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.shiftNumberGroupBox.Location = new System.Drawing.Point(22, 89);
            this.shiftNumberGroupBox.Name = "shiftNumberGroupBox";
            this.shiftNumberGroupBox.Size = new System.Drawing.Size(291, 57);
            this.shiftNumberGroupBox.TabIndex = 1;
            this.shiftNumberGroupBox.TabStop = false;
            this.shiftNumberGroupBox.Text = "Shift Number: ";
            // 
            // nightRadioButton
            // 
            this.nightRadioButton.AutoSize = true;
            this.nightRadioButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.nightRadioButton.Location = new System.Drawing.Point(210, 22);
            this.nightRadioButton.Name = "nightRadioButton";
            this.nightRadioButton.Size = new System.Drawing.Size(71, 19);
            this.nightRadioButton.TabIndex = 0;
            this.nightRadioButton.TabStop = true;
            this.nightRadioButton.Text = "night (2)";
            this.nightRadioButton.UseVisualStyleBackColor = true;
            this.nightRadioButton.CheckedChanged += new System.EventHandler(this.nightRadioButton_CheckedChanged);
            // 
            // dayRadioButton
            // 
            this.dayRadioButton.AutoSize = true;
            this.dayRadioButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dayRadioButton.Location = new System.Drawing.Point(143, 22);
            this.dayRadioButton.Name = "dayRadioButton";
            this.dayRadioButton.Size = new System.Drawing.Size(63, 19);
            this.dayRadioButton.TabIndex = 0;
            this.dayRadioButton.TabStop = true;
            this.dayRadioButton.Text = "day (1)";
            this.dayRadioButton.UseVisualStyleBackColor = true;
            this.dayRadioButton.CheckedChanged += new System.EventHandler(this.dayRadioButton_CheckedChanged);
            // 
            // hourlyPayRateLabel
            // 
            this.hourlyPayRateLabel.AutoSize = true;
            this.hourlyPayRateLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.hourlyPayRateLabel.Location = new System.Drawing.Point(22, 155);
            this.hourlyPayRateLabel.Name = "hourlyPayRateLabel";
            this.hourlyPayRateLabel.Size = new System.Drawing.Size(115, 15);
            this.hourlyPayRateLabel.TabIndex = 0;
            this.hourlyPayRateLabel.Text = "Hourly Pay Rate: $  ";
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(144, 17);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(154, 23);
            this.employeeNameTextBox.TabIndex = 2;
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(143, 47);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(154, 23);
            this.employeeNumberTextBox.TabIndex = 2;
            // 
            // hourlyPayRateTextBox
            // 
            this.hourlyPayRateTextBox.Location = new System.Drawing.Point(137, 152);
            this.hourlyPayRateTextBox.Name = "hourlyPayRateTextBox";
            this.hourlyPayRateTextBox.Size = new System.Drawing.Size(161, 23);
            this.hourlyPayRateTextBox.TabIndex = 2;
            // 
            // displayButton
            // 
            this.displayButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.displayButton.Location = new System.Drawing.Point(194, 181);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(97, 29);
            this.displayButton.TabIndex = 3;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(22, 223);
            this.outputLabel.MinimumSize = new System.Drawing.Size(280, 130);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(280, 130);
            this.outputLabel.TabIndex = 4;
            // 
            // EmployeeAndProductionWorkerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 369);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.hourlyPayRateTextBox);
            this.Controls.Add(this.employeeNumberTextBox);
            this.Controls.Add(this.employeeNameTextBox);
            this.Controls.Add(this.shiftNumberGroupBox);
            this.Controls.Add(this.hourlyPayRateLabel);
            this.Controls.Add(this.employeeNumberLabel);
            this.Controls.Add(this.employeeNameLabel);
            this.Name = "EmployeeAndProductionWorkerForm";
            this.Text = "Employee & ProductionWorker Form";
            this.shiftNumberGroupBox.ResumeLayout(false);
            this.shiftNumberGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.GroupBox shiftNumberGroupBox;
        private System.Windows.Forms.RadioButton nightRadioButton;
        private System.Windows.Forms.RadioButton dayRadioButton;
        private System.Windows.Forms.Label hourlyPayRateLabel;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.TextBox hourlyPayRateTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label outputLabel;
    }
}