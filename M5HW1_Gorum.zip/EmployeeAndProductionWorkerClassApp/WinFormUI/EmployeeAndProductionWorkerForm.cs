﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program allows user to enter information into a form about an employee and displays this information back to the user. Program utilizes inheritance of classes Employee class and ProductionWorker class.
*/

using System;
using EmployeeAndProductionWorkerClassLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class EmployeeAndProductionWorkerForm : Form
    {
        //ProductionWorker object Initialization
        ProductionWorker pdWorker = new ProductionWorker();

        public EmployeeAndProductionWorkerForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign values to the pdWorker object's properties based on the input passed in the forms text boxes.
                pdWorker.EmployeeName = employeeNameTextBox.Text;
                pdWorker.EmployeeNumber = int.Parse(employeeNumberTextBox.Text);
                pdWorker.HourlyPayRate = decimal.Parse(hourlyPayRateTextBox.Text);

                //Display to the user the pdWorker object's properties in the output label of the form.
                outputLabel.Text = "Employee Name: " + pdWorker.EmployeeName + "\n" +
                    "Employee Number: " + pdWorker.EmployeeNumber + "\n" +
                    "Shift Number: " + pdWorker.ShiftNumber + "\n" +
                    "Hourly pay rate: " + pdWorker.HourlyPayRate.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dayRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (dayRadioButton.Checked)
            {
                //Assign the pdWorker object's ShiftNumber property based on the radio button checked.
                pdWorker.ShiftNumber = 1;
            }
        }

        private void nightRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (nightRadioButton.Checked)
            {
                //Assign the pdWorker object's ShiftNumber property based on the radio button checked.
                pdWorker.ShiftNumber = 2;
            }
        }
    }
}
