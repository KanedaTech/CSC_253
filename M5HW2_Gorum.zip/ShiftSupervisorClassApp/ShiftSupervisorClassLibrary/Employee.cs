﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program receives input from user and assigns it to the properties of a ShiftSupervisor class that inherits properties from an Employee class, then displays that input back to the user in the form.
*/
namespace ShiftSupervisorClassLibrary
{
    //Create public class Employee.
    public class Employee
    {
        //Create a default constructor for Employee class.
        public Employee()
        {
            Name = "Raw Meat";
            Number = 1000;
        }
        //Initialize properties for Employee class.
        public string Name { get; set; }
        public int Number { get; set; }

    }
}
