﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program receives input from user and assigns it to the properties of a ShiftSupervisor class that inherits properties from an Employee class, then displays that input back to the user in the form.
*/
namespace ShiftSupervisorClassLibrary
{
    //Create ShiftSupervisor class that inherits from Employee class.
    public class ShiftSupervisor : Employee
    {
        //Create default constructor for ShiftSupervisor class.
        public ShiftSupervisor()
        {
            Salary = 56000.00m;
            ResponsibleShift = "Day";
            YearlyBonus = 0.00m;
        }
        
        //Initialize properties for ShiftSupervisor class.
        public decimal Salary { get; set; }
        public string ResponsibleShift { get; set; }
        public decimal YearlyBonus { get; set; }
    }
}
