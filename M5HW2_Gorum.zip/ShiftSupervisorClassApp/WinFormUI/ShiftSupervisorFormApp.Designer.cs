﻿
namespace WinFormUI
{
    partial class ShiftSupervisorFormApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftGroupBox = new System.Windows.Forms.GroupBox();
            this.daysRadioButton = new System.Windows.Forms.RadioButton();
            this.eveningsRadioButton = new System.Windows.Forms.RadioButton();
            this.productionGoalsMetCheckBox = new System.Windows.Forms.CheckBox();
            this.annualSalaryLabel = new System.Windows.Forms.Label();
            this.productionBonusLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.annualSalaryTextBox = new System.Windows.Forms.TextBox();
            this.prodBonusTextBox = new System.Windows.Forms.TextBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.shiftGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(12, 9);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(130, 15);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Shift Supervisor Name: ";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(12, 48);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(142, 15);
            this.numberLabel.TabIndex = 0;
            this.numberLabel.Text = "Shift Supervisor Number: ";
            // 
            // shiftGroupBox
            // 
            this.shiftGroupBox.Controls.Add(this.eveningsRadioButton);
            this.shiftGroupBox.Controls.Add(this.daysRadioButton);
            this.shiftGroupBox.Location = new System.Drawing.Point(12, 85);
            this.shiftGroupBox.Name = "shiftGroupBox";
            this.shiftGroupBox.Size = new System.Drawing.Size(328, 73);
            this.shiftGroupBox.TabIndex = 1;
            this.shiftGroupBox.TabStop = false;
            this.shiftGroupBox.Text = "Responsible Shift";
            // 
            // daysRadioButton
            // 
            this.daysRadioButton.AutoSize = true;
            this.daysRadioButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.daysRadioButton.Location = new System.Drawing.Point(36, 31);
            this.daysRadioButton.Name = "daysRadioButton";
            this.daysRadioButton.Size = new System.Drawing.Size(57, 23);
            this.daysRadioButton.TabIndex = 0;
            this.daysRadioButton.TabStop = true;
            this.daysRadioButton.Text = "Days";
            this.daysRadioButton.UseVisualStyleBackColor = true;
            this.daysRadioButton.CheckedChanged += new System.EventHandler(this.daysRadioButton_CheckedChanged);
            // 
            // eveningsRadioButton
            // 
            this.eveningsRadioButton.AutoSize = true;
            this.eveningsRadioButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.eveningsRadioButton.Location = new System.Drawing.Point(198, 31);
            this.eveningsRadioButton.Name = "eveningsRadioButton";
            this.eveningsRadioButton.Size = new System.Drawing.Size(81, 23);
            this.eveningsRadioButton.TabIndex = 0;
            this.eveningsRadioButton.TabStop = true;
            this.eveningsRadioButton.Text = "Evenings";
            this.eveningsRadioButton.UseVisualStyleBackColor = true;
            this.eveningsRadioButton.CheckedChanged += new System.EventHandler(this.eveningsRadioButton_CheckedChanged);
            // 
            // productionGoalsMetCheckBox
            // 
            this.productionGoalsMetCheckBox.AutoSize = true;
            this.productionGoalsMetCheckBox.Location = new System.Drawing.Point(12, 225);
            this.productionGoalsMetCheckBox.Name = "productionGoalsMetCheckBox";
            this.productionGoalsMetCheckBox.Size = new System.Drawing.Size(146, 19);
            this.productionGoalsMetCheckBox.TabIndex = 2;
            this.productionGoalsMetCheckBox.Text = "Production Goals Met?";
            this.productionGoalsMetCheckBox.UseVisualStyleBackColor = true;
            this.productionGoalsMetCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // annualSalaryLabel
            // 
            this.annualSalaryLabel.AutoSize = true;
            this.annualSalaryLabel.Location = new System.Drawing.Point(12, 170);
            this.annualSalaryLabel.Name = "annualSalaryLabel";
            this.annualSalaryLabel.Size = new System.Drawing.Size(94, 15);
            this.annualSalaryLabel.TabIndex = 0;
            this.annualSalaryLabel.Text = "Annual Salary:  $";
            // 
            // productionBonusLabel
            // 
            this.productionBonusLabel.AutoSize = true;
            this.productionBonusLabel.Location = new System.Drawing.Point(12, 199);
            this.productionBonusLabel.Name = "productionBonusLabel";
            this.productionBonusLabel.Size = new System.Drawing.Size(120, 15);
            this.productionBonusLabel.TabIndex = 0;
            this.productionBonusLabel.Text = "Production Bonus:   $";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(152, 9);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(234, 23);
            this.nameTextBox.TabIndex = 3;
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(152, 45);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(234, 23);
            this.numberTextBox.TabIndex = 3;
            // 
            // annualSalaryTextBox
            // 
            this.annualSalaryTextBox.Location = new System.Drawing.Point(112, 167);
            this.annualSalaryTextBox.Name = "annualSalaryTextBox";
            this.annualSalaryTextBox.Size = new System.Drawing.Size(274, 23);
            this.annualSalaryTextBox.TabIndex = 3;
            // 
            // prodBonusTextBox
            // 
            this.prodBonusTextBox.Location = new System.Drawing.Point(138, 196);
            this.prodBonusTextBox.Name = "prodBonusTextBox";
            this.prodBonusTextBox.Size = new System.Drawing.Size(248, 23);
            this.prodBonusTextBox.TabIndex = 3;
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(75, 327);
            this.outputLabel.MinimumSize = new System.Drawing.Size(240, 130);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(240, 130);
            this.outputLabel.TabIndex = 4;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(75, 274);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(240, 41);
            this.displayButton.TabIndex = 5;
            this.displayButton.Text = "Display Results";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // ShiftSupervisorFormApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 466);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.prodBonusTextBox);
            this.Controls.Add(this.annualSalaryTextBox);
            this.Controls.Add(this.numberTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.productionGoalsMetCheckBox);
            this.Controls.Add(this.shiftGroupBox);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.productionBonusLabel);
            this.Controls.Add(this.annualSalaryLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "ShiftSupervisorFormApp";
            this.Text = "Shift Supervisor Class App";
            this.shiftGroupBox.ResumeLayout(false);
            this.shiftGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.GroupBox shiftGroupBox;
        private System.Windows.Forms.RadioButton eveningsRadioButton;
        private System.Windows.Forms.RadioButton daysRadioButton;
        private System.Windows.Forms.CheckBox productionGoalsMetCheckBox;
        private System.Windows.Forms.Label annualSalaryLabel;
        private System.Windows.Forms.Label productionBonusLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox annualSalaryTextBox;
        private System.Windows.Forms.TextBox prodBonusTextBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button displayButton;
    }
}

