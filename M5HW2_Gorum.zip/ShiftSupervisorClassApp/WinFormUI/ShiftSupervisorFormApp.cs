﻿/**
* 10-26-21
* CSC 253
* Adrian Gorum
* Program receives input from user and assigns it to the properties of a ShiftSupervisor class that inherits properties from an Employee class, then displays that input back to the user in the form.
*/
using System;
using ShiftSupervisorClassLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class ShiftSupervisorFormApp : Form
    {
        //Create instance of ShiftSupervisor object
        ShiftSupervisor shiftSupe = new ShiftSupervisor();

        public ShiftSupervisorFormApp()
        {
            InitializeComponent();
        }
        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (nameTextBox.Text is not null && numberTextBox.Text is not null && annualSalaryTextBox.Text is not null)
                {
                    //Assign shiftSupe object's properties the values from the form's textboxes.
                    shiftSupe.Name = nameTextBox.Text;
                    shiftSupe.Number = int.Parse(numberTextBox.Text);
                    shiftSupe.Salary = decimal.Parse(annualSalaryTextBox.Text);                    
                }
                else
                {
                    //Assign the default constructor values to the objects properties.
                    shiftSupe.Name = shiftSupe.Name;
                    shiftSupe.Number = shiftSupe.Number;
                    shiftSupe.Salary = shiftSupe.Salary;
                }
                //Display the information to the user using the outputLabel.
                outputLabel.Text = "Shift Supervisor Name: " + shiftSupe.Name + "\n" +
                    "Shift Supervisor Number: " + shiftSupe.Number + "\n" +
                    "Annual Salary: $" + shiftSupe.Salary + "\n" +
                    "Production Bonus: $" + shiftSupe.YearlyBonus + "\n" +
                    "Total Yearly Earnings: $" + (shiftSupe.Salary + shiftSupe.YearlyBonus);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //Check if the productionGoalsMetCheckBox is checked, if so set the shiftSupe object's property to the input from user.
            if (productionGoalsMetCheckBox.Checked)
            {
                shiftSupe.YearlyBonus = decimal.Parse(prodBonusTextBox.Text);
            }
            else
            {
                shiftSupe.YearlyBonus = shiftSupe.YearlyBonus;
            }
        }

        private void daysRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (daysRadioButton.Checked)
            {
                shiftSupe.ResponsibleShift = "Days";
            }
        }

        private void eveningsRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (eveningsRadioButton.Checked)
            {
                shiftSupe.ResponsibleShift = "Evenings";
            }
        }
    }
}
