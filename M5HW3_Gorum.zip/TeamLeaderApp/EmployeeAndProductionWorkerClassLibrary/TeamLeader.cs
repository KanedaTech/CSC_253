﻿/**
* 10-29-21
* CSC 253
* Adrian Gorum
* Program allows user to enter information into a form about a team leader employee and displays this information back to the user. Program utilizes inheritance of classes Employee class & ProductionWorker class.
*/
namespace EmployeeAndProductionWorkerClassLibrary
{
    //TeamLeader inherites properties from ProductionWorker class.
    public class TeamLeader : ProductionWorker
    {
        //Initialize TeamLeader class properties.
        public decimal MonthlyBonus { get; set; }
        public int RequiredTrainingHours { get; set; }
        public int TrainingHoursAttended { get; set; }

        //Create Default Constructor for TeamLeader class.
        public TeamLeader()
        {
            MonthlyBonus = 0.00m;
            RequiredTrainingHours = 6;
            TrainingHoursAttended = 0;
        }
    }
}
