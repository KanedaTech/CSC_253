﻿/**
* 10-29-21
* CSC 253
* Adrian Gorum
* Program allows user to enter information into a form about a team leader employee and displays this information back to the user. Program utilizes inheritance of classes Employee class & ProductionWorker class.
*/

using System;
using EmployeeAndProductionWorkerClassLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class TeamLeaderAppForm : Form
    {
        //TeamLeader object Initialization
        TeamLeader teamLead = new TeamLeader();

        public TeamLeaderAppForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Assign values to the teamLead object's properties based on the input passed in the forms text boxes.
                teamLead.EmployeeName = employeeNameTextBox.Text;
                teamLead.EmployeeNumber = int.Parse(employeeNumberTextBox.Text);
                teamLead.HourlyPayRate = decimal.Parse(hourlyPayRateTextBox.Text);
                teamLead.MonthlyBonus = decimal.Parse(MonthlyBonusTextBox.Text);
                teamLead.RequiredTrainingHours = int.Parse(ReqTrainHrsTextBox.Text);
                teamLead.TrainingHoursAttended = int.Parse(TrainingHoursAttendedTextBox.Text);

                //Check if the required training hours have been met. 
                if (teamLead.RequiredTrainingHours != teamLead.TrainingHoursAttended)
                {
                    //If required training hours have not been met assign MonthlyBonus property value of 0.00.
                    teamLead.MonthlyBonus = 0.00m;
                }

                //Display to the user the teamLead object's properties in the output label of the form.
                outputLabel.Text = "Employee Name: " + teamLead.EmployeeName + "\n" +
                    "Employee Number: " + teamLead.EmployeeNumber + "\n" +
                    "Shift Number: " + teamLead.ShiftNumber + "\n" +
                    "Hourly pay rate: " + teamLead.HourlyPayRate.ToString("c") + "\n" +
                    "Monthly bonus amount: $" + teamLead.MonthlyBonus + "\n" +
                    "Required Training Hours: " + teamLead.RequiredTrainingHours + "\n" +
                    "Training hours attended: " + teamLead.TrainingHoursAttended;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dayRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (dayRadioButton.Checked)
            {
                //Assign the teamLead object's ShiftNumber property based on the radio button checked.
                teamLead.ShiftNumber = 1;
            }
        }

        private void nightRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (nightRadioButton.Checked)
            {
                //Assign the teamLead object's ShiftNumber property based on the radio button checked.
                teamLead.ShiftNumber = 2;
            }
        }
    }
}
