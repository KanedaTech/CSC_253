﻿/**
* 11-3-2021
* CSC 253
* Adrian Gorum
* Program uses a variety of extension methods to manipulate string data inputed by the user. 
*/
using System;

namespace ExtensionMethodClassLibrary
{
    public static class ExtensionMethods
    {
        public static char[] StringToCharArray(this string inputString)
        {
            //Initialize a char array.
            char[] charArray = new char[1];

            //Check if the length of the inputString is greater than 0.
            if (inputString.Length > 0)
            {
                //Set charArray value to inputString converted to CharArray.
                charArray = inputString.ToCharArray();

                //Return charArray.
                return charArray; ;
            }
            else
            {
                //Returns empty array.
                return charArray;
            }
        }

        public static string[] DateToStringArray(this string inputString)
        {
            //Initialize string array and assign it the inputString split using the delimiter "/"
            string[] dateArray = inputString.Split("/");

            //Retrun the array.
            return dateArray;
        }

        public static string StringToTelephoneNumber(this string inputString)
        {
            //Check if the inputString variable is empty and if the length is equal to 10 characters.
            if (inputString != null && inputString.Trim().Length == 10)
            {
                //Return the inputString formatted based on its substrings.
                return string.Format("({0}) {1}-{2}", inputString.Substring(0, 3), inputString.Substring(3, 3), inputString.Substring(6, 4));
            }
            //Return the original inputString value.
            return inputString;
        }

        public static string ReverseString(this string inputString)
        {
            //Initialize char array assign value of string converter to char array.
            char[] charArray = inputString.ToCharArray();

            //Reverse the chars in array using Array datatype Reverse() method.
            Array.Reverse(charArray);

            //Initialize string and assign it a new string value passing the charArray[].
            string reverseString = new string(charArray);

            //Returns the string in reverse.
            return reverseString;
        }

        public static string NumberOfWords(this string inputString)
        {
            //Initialize character array with all the delimiters needed to be recognized by the Split() method.
            char[] delimiters = new char[] { ' ', ',', '\r', '.', ':', '\t' };

            //Initialize and assign int variable the number of words in a string using Split() method and retrieving the length.
            int wordCount = inputString.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Length;

            //Initialize string variable and convert the wordCount variable to a string.
            string totalWordCount = Convert.ToString(wordCount);

            //Return the string variable totalWordCount
            return totalWordCount;

        }

    }
}
