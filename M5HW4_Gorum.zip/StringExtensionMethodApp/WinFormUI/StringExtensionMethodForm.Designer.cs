﻿
namespace WinFormUI
{
    partial class StringExtensionMethodForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputStringLabel = new System.Windows.Forms.Label();
            this.StringInputTextBox = new System.Windows.Forms.TextBox();
            this.DisplayLabel = new System.Windows.Forms.Label();
            this.StringToCharArrayButton = new System.Windows.Forms.Button();
            this.ConvertDateButton = new System.Windows.Forms.Button();
            this.StringToTelephoneButton = new System.Windows.Forms.Button();
            this.ReverseStringButton = new System.Windows.Forms.Button();
            this.WordCountButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // InputStringLabel
            // 
            this.InputStringLabel.AutoSize = true;
            this.InputStringLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.InputStringLabel.Location = new System.Drawing.Point(30, 33);
            this.InputStringLabel.Name = "InputStringLabel";
            this.InputStringLabel.Size = new System.Drawing.Size(80, 15);
            this.InputStringLabel.TabIndex = 0;
            this.InputStringLabel.Text = "Input String: ";
            // 
            // StringInputTextBox
            // 
            this.StringInputTextBox.Location = new System.Drawing.Point(111, 30);
            this.StringInputTextBox.Name = "StringInputTextBox";
            this.StringInputTextBox.Size = new System.Drawing.Size(230, 23);
            this.StringInputTextBox.TabIndex = 1;
            // 
            // DisplayLabel
            // 
            this.DisplayLabel.AutoSize = true;
            this.DisplayLabel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DisplayLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DisplayLabel.ForeColor = System.Drawing.SystemColors.Info;
            this.DisplayLabel.Location = new System.Drawing.Point(12, 285);
            this.DisplayLabel.MinimumSize = new System.Drawing.Size(340, 220);
            this.DisplayLabel.Name = "DisplayLabel";
            this.DisplayLabel.Size = new System.Drawing.Size(340, 220);
            this.DisplayLabel.TabIndex = 2;
            this.DisplayLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StringToCharArrayButton
            // 
            this.StringToCharArrayButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StringToCharArrayButton.Location = new System.Drawing.Point(30, 90);
            this.StringToCharArrayButton.Name = "StringToCharArrayButton";
            this.StringToCharArrayButton.Size = new System.Drawing.Size(144, 64);
            this.StringToCharArrayButton.TabIndex = 3;
            this.StringToCharArrayButton.Text = "Convert String to Char Array";
            this.StringToCharArrayButton.UseVisualStyleBackColor = true;
            this.StringToCharArrayButton.Click += new System.EventHandler(this.StringToCharArrayButton_Click);
            // 
            // ConvertDateButton
            // 
            this.ConvertDateButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ConvertDateButton.Location = new System.Drawing.Point(193, 90);
            this.ConvertDateButton.Name = "ConvertDateButton";
            this.ConvertDateButton.Size = new System.Drawing.Size(148, 64);
            this.ConvertDateButton.TabIndex = 4;
            this.ConvertDateButton.Text = "Convert Date String (mm/dd/yyyy) to String Array";
            this.ConvertDateButton.UseVisualStyleBackColor = true;
            this.ConvertDateButton.Click += new System.EventHandler(this.ConvertDateButton_Click);
            // 
            // StringToTelephoneButton
            // 
            this.StringToTelephoneButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StringToTelephoneButton.Location = new System.Drawing.Point(30, 172);
            this.StringToTelephoneButton.Name = "StringToTelephoneButton";
            this.StringToTelephoneButton.Size = new System.Drawing.Size(144, 63);
            this.StringToTelephoneButton.TabIndex = 5;
            this.StringToTelephoneButton.Text = "Convert 10 Character String to Telephone Number";
            this.StringToTelephoneButton.UseVisualStyleBackColor = true;
            this.StringToTelephoneButton.Click += new System.EventHandler(this.StringToTelephoneButton_Click);
            // 
            // ReverseStringButton
            // 
            this.ReverseStringButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ReverseStringButton.Location = new System.Drawing.Point(193, 172);
            this.ReverseStringButton.Name = "ReverseStringButton";
            this.ReverseStringButton.Size = new System.Drawing.Size(148, 63);
            this.ReverseStringButton.TabIndex = 6;
            this.ReverseStringButton.Text = "Reverse String Input";
            this.ReverseStringButton.UseVisualStyleBackColor = true;
            this.ReverseStringButton.Click += new System.EventHandler(this.ReverseStringButton_Click);
            // 
            // WordCountButton
            // 
            this.WordCountButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.WordCountButton.Location = new System.Drawing.Point(30, 241);
            this.WordCountButton.Name = "WordCountButton";
            this.WordCountButton.Size = new System.Drawing.Size(311, 34);
            this.WordCountButton.TabIndex = 7;
            this.WordCountButton.Text = "Count Number of Words In String";
            this.WordCountButton.UseVisualStyleBackColor = true;
            this.WordCountButton.Click += new System.EventHandler(this.WordCountButton_Click);
            // 
            // StringExtensionMethodForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 523);
            this.Controls.Add(this.WordCountButton);
            this.Controls.Add(this.ReverseStringButton);
            this.Controls.Add(this.StringToTelephoneButton);
            this.Controls.Add(this.ConvertDateButton);
            this.Controls.Add(this.StringToCharArrayButton);
            this.Controls.Add(this.DisplayLabel);
            this.Controls.Add(this.StringInputTextBox);
            this.Controls.Add(this.InputStringLabel);
            this.Name = "StringExtensionMethodForm";
            this.Text = "String Extension Method App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label InputStringLabel;
        private System.Windows.Forms.TextBox StringInputTextBox;
        private System.Windows.Forms.Label DisplayLabel;
        private System.Windows.Forms.Button StringToCharArrayButton;
        private System.Windows.Forms.Button ConvertDateButton;
        private System.Windows.Forms.Button StringToTelephoneButton;
        private System.Windows.Forms.Button ReverseStringButton;
        private System.Windows.Forms.Button WordCountButton;
    }
}

