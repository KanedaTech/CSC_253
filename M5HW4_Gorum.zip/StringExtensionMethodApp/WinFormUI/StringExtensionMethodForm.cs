﻿/**
* 11-3-2021
* CSC 253
* Adrian Gorum
* Program uses a variety of extension methods to manipulate string data inputed by the user. 
*/
using System;
using ExtensionMethodClassLibrary;

using System.Windows.Forms;

namespace WinFormUI
{
    public partial class StringExtensionMethodForm : Form
    {
        public StringExtensionMethodForm()
        {
            InitializeComponent();
        }

        private void StringToCharArrayButton_Click(object sender, EventArgs e)
        {
            //Initialize inputString variable and set the value equal to the StringInputTextBox text.
            string inputString = StringInputTextBox.Text;

            //Initialize charArray and set it to the value returned by the extension method called.
            char[] charArray = ExtensionMethods.StringToCharArray(inputString);

            //Display information in the DisplayLabel.
            DisplayLabel.Text = "Char charArray[] elements\n\n" + String.Join("       ", charArray);
        }

        private void ConvertDateButton_Click(object sender, EventArgs e)
        {
            //Initialize inputString variable and set the value equal to the StringInputTextBox text.
            string inputString = StringInputTextBox.Text;

            //Initialize dateArray and set it to the value returned by the extension method called.
            string[] dateArray = ExtensionMethods.DateToStringArray(inputString);

            //Display information in the DisplayLabel.
            DisplayLabel.Text = "string dateArray[] elements\n\n" + String.Join("        ", dateArray);
        }

        private void StringToTelephoneButton_Click(object sender, EventArgs e)
        {
            //Initialize inputString variable and set the value equal to the StringInputTextBox text.
            string inputString = StringInputTextBox.Text;

            //Initialize string variable and set it to the value returned by the extension method called.
            string telephoneNumber = ExtensionMethods.StringToTelephoneNumber(inputString);

            //Display information in the DisplayLabel.
            DisplayLabel.Text = "10 Character String to Telephone Number\n\n" + telephoneNumber;
        }

        private void ReverseStringButton_Click(object sender, EventArgs e)
        {
            //Initialize inputString variable and set the value equal to the StringInputTextBox text.
            string inputString = StringInputTextBox.Text;

            //Initialize string variable and set it to the value returned by the extension method called.
            string reversedString = ExtensionMethods.ReverseString(inputString);

            //Display information in the DisplayLabel.
            DisplayLabel.Text = "String Reversed\n\n" + reversedString;
        }

        private void WordCountButton_Click(object sender, EventArgs e)
        {
            //Initialize inputString variable and set the value equal to the StringInputTextBox text.
            string inputString = StringInputTextBox.Text;

            //Initialize string variable and set it to the value returned by the extension method called.
            string wordCount = ExtensionMethods.NumberOfWords(inputString);

            //Display information in the DisplayLabel.
            DisplayLabel.Text = "Number of words in string = " + wordCount;
        }
    }
}
