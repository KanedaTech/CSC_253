/**
* 11/16/21
* CSC 253
* Adrian Gorum
* Program uses a loop to increase the base tuition value for the next 5 years. Implements a unit test to ensure the method works.
*/
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MyClassLibrary;
using System.Collections.Generic;

namespace GetTutitionTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void Validate_GetTution()
        {
            // arrange

            // initialize variables
            List<double> tuitionList = new List<double>();
            var expectedList = new List<double>();

            double baseTuition = 6000.00;
            double tuitionIncRate = .06;

            for (int i = 0; i <= 5; i++)
            {
                expectedList.Add(Math.Round(baseTuition));
                baseTuition += (baseTuition * tuitionIncRate);
            }            

            // act

            // assign list to tuitionList with method call GetTuitionList().
            tuitionList = Methods.GetTuitionList();

            // assert

            // check if the two lists are the same.
            CollectionAssert.AreEqual(expectedList, tuitionList);
        }
    }
}
