﻿/**
* 11/16/21
* CSC 253
* Adrian Gorum
* Program uses a loop to increase the base tuition value for the next 5 years. Implements a unit test to ensure the method works.
*/
using System;
using System.Collections.Generic;

namespace MyClassLibrary
{
    public class Methods
    {
        // Create method that returns a list.
        public static List<double> GetTuitionList()
        {
            // Initialize list type double.
            List<double> tuitionList = new List<double>();
            // Initialize type double variables to hold values.
            double baseTuition = 6000.00;
            double tuitionIncRate = .06;
            // For loop iterates 5 times and adds element to tuitionList
            for (int i=0; i<=5;i++)
            {
                tuitionList.Add(Math.Round(baseTuition));
                baseTuition += (baseTuition * tuitionIncRate);
            }
            // Return tuitionList.
            return tuitionList;
        }
    }
}
