﻿
namespace WinFormUI
{
    partial class TuitionIncreaseForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DisplayButton = new System.Windows.Forms.Button();
            this.TuitionListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // DisplayButton
            // 
            this.DisplayButton.Location = new System.Drawing.Point(12, 12);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Size = new System.Drawing.Size(219, 97);
            this.DisplayButton.TabIndex = 0;
            this.DisplayButton.Text = "Display Increased Tuition";
            this.DisplayButton.UseVisualStyleBackColor = true;
            this.DisplayButton.Click += new System.EventHandler(this.DisplayButton_Click);
            // 
            // TuitionListBox
            // 
            this.TuitionListBox.FormattingEnabled = true;
            this.TuitionListBox.ItemHeight = 15;
            this.TuitionListBox.Location = new System.Drawing.Point(12, 114);
            this.TuitionListBox.Name = "TuitionListBox";
            this.TuitionListBox.Size = new System.Drawing.Size(219, 169);
            this.TuitionListBox.TabIndex = 1;
            // 
            // TuitionIncreaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 295);
            this.Controls.Add(this.TuitionListBox);
            this.Controls.Add(this.DisplayButton);
            this.Name = "TuitionIncreaseForm";
            this.Text = "Tuition Increase App";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button DisplayButton;
        private System.Windows.Forms.ListBox TuitionListBox;
    }
}

