﻿/**
* 11/16/21
* CSC 253
* Adrian Gorum
* Program uses a loop to increase the base tuition value for the next 5 years. Implements a unit test to ensure the method works.
*/
using System;
using System.Collections.Generic;
using MyClassLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class TuitionIncreaseForm : Form
    {
        public TuitionIncreaseForm()
        {
            InitializeComponent();
        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            // Initialize type double list and assign it the list value of the method call GetTuitionList().
            List<double> tuitionList = Methods.GetTuitionList();
            // Iterate over the list 5 times to display the elements in the list.
            for (int i=0;i<5;i++)
            {
                TuitionListBox.Items.Add("Year " + (i+1) + " tutition:    " + "$" + tuitionList[i].ToString("N"));
            }

        }
    }
}
