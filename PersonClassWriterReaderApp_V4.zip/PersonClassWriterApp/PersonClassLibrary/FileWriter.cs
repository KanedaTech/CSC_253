﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using System.IO;

namespace PersonClassLibrary
{
    //Create class FileWriter
    public static class FileWriter
    {
        //Create WriteToFile method that returns a string value. Writes data to a file.
        public static string WriteToFile()
        {
            //Create a StreamWriter object outFile.
            StreamWriter outFile;
            //Use Try/Catch clause for exceptions handling.
            try
            {
                //Assign outFile object the value of File.CreateText() method call. Creates document.
                outFile = File.CreateText("UserInformation.csv");
                //Use foreach loop and iterate over the people list created by the ListBuilder class.  Set PersonClass properties to object person.
                foreach (PersonClass person in ListBuilder.people)
                {
                    //Write person properties to outFile object.
                    outFile.WriteLine($"{person.FirstName}, {person.MiddleName}, {person.LastName}, {person.Age}");
                }
                //Close file.
                outFile.Close();
                //Return string value.
                return "File Saved.";
            }
            catch(Exception ex)
            {
                //Initialse string variable message and assign it the exception message;
                string message = ex.Message;
                //Return message variable.
                return message;
            }
        }
    }
}
