﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System.Collections.Generic;

namespace PersonClassLibrary
{
    //Create class ListBuilder.
    public static class ListBuilder
    {
        //Initialize List object people.
        public static List<PersonClass> people = new List<PersonClass>();
        //Create BuildList method that takes multiple arguments to build a list.
        public static void BuildList(string firstName, string middleName, string lastName, int age)
        {
            //Add PersonClass property values to the people list.
            people.Add(new PersonClass(firstName, middleName, lastName, age));
        }
    }
}
