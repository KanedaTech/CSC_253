﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
//Create PersonClassLibray.
namespace PersonClassLibrary
{
    //Create PersonClass.
    public class PersonClass
    {
        //Create PersonClass Constructor with parameters.
        public PersonClass(string firstName, string middleName, string lastName, int age)
        {
            //Assign parameter values as class property values.
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Age = age;
        }
        //Initialize class properties (auto-properties).
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }
}
