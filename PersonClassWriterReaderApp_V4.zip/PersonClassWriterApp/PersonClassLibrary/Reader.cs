﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using System.IO;

namespace PersonClassLibrary
{
    //Create class Reader.
    public static class Reader
    {
        //Create ReadUserInfoFile() method that returns a string value.
        public static string ReadUserInfoFile()
        {
            //Create a StreamReader object inputFile.
            StreamReader inputFile;
            //Use Try/Catch clause for exceptions handling.
            try
            {
                //Assign inputFile object the value of File.OpenText() method call. Reads specifid document passed as argument.
                inputFile = File.OpenText("UserInformation.csv");
                //Utilize while loop to iterate over inputFile object until the StreamReader reaches the end of the file.
                while(!inputFile.EndOfStream)
                {
                    //Initialize string array tokens and assign the value of inputFile.Readline() method call. Use Split() method call to create substrings delimited by the passed argument.
                    string[] tokens = inputFile.ReadLine().Split(',');
                    //Add tokens substrings to people List created by ListBuilder class. 4 indecies. 
                    ListBuilder.people.Add(new PersonClass(tokens[0], tokens[1], tokens[2], int.Parse(tokens[3])));
                }
                //Close inputFile object.
                inputFile.Close();
                //Return string value.
                return "File Loaded.";    
            }
            catch(Exception ex)
            {
                //Initialize string message assigned value of message from an Exception.
                string message = ex.Message;
                //Return message variable.
                return message;
            }
        }
    }
}
