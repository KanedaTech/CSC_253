﻿
namespace WinFormUI
{
    partial class DecisionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PromptLabel = new System.Windows.Forms.Label();
            this.WriterFormButton = new System.Windows.Forms.Button();
            this.ReaderFormButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PromptLabel
            // 
            this.PromptLabel.AutoSize = true;
            this.PromptLabel.Location = new System.Drawing.Point(88, 19);
            this.PromptLabel.Name = "PromptLabel";
            this.PromptLabel.Size = new System.Drawing.Size(105, 15);
            this.PromptLabel.TabIndex = 0;
            this.PromptLabel.Text = "Open which form?";
            // 
            // WriterFormButton
            // 
            this.WriterFormButton.Location = new System.Drawing.Point(8, 62);
            this.WriterFormButton.Name = "WriterFormButton";
            this.WriterFormButton.Size = new System.Drawing.Size(117, 64);
            this.WriterFormButton.TabIndex = 1;
            this.WriterFormButton.Text = "Open Person Class Writer Form";
            this.WriterFormButton.UseVisualStyleBackColor = true;
            this.WriterFormButton.Click += new System.EventHandler(this.WriterFormButton_Click);
            // 
            // ReaderFormButton
            // 
            this.ReaderFormButton.Location = new System.Drawing.Point(151, 62);
            this.ReaderFormButton.Name = "ReaderFormButton";
            this.ReaderFormButton.Size = new System.Drawing.Size(117, 64);
            this.ReaderFormButton.TabIndex = 1;
            this.ReaderFormButton.Text = "Open Person Class Reader Form";
            this.ReaderFormButton.UseVisualStyleBackColor = true;
            this.ReaderFormButton.Click += new System.EventHandler(this.ReaderFormButton_Click);
            // 
            // DecisionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(280, 138);
            this.Controls.Add(this.ReaderFormButton);
            this.Controls.Add(this.WriterFormButton);
            this.Controls.Add(this.PromptLabel);
            this.Name = "DecisionForm";
            this.Text = "Decision Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PromptLabel;
        private System.Windows.Forms.Button WriterFormButton;
        private System.Windows.Forms.Button ReaderFormButton;
    }
}