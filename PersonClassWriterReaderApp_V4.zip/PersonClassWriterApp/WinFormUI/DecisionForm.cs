﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class DecisionForm : Form
    {
        public DecisionForm()
        {
            InitializeComponent();
        }
        //Initialize bool auto property.
        public bool isWriterChoice { get; set; }

        private void WriterFormButton_Click(object sender, EventArgs e)
        {
            //Close DecisionForm.
            this.Close();
            //Set isWriterChoice property to true;
            isWriterChoice = true;
        }

        private void ReaderFormButton_Click(object sender, EventArgs e)
        {
            //Close Decision Form
            this.Close();
            //Set isWriterChoice to false.
            isWriterChoice = false;
        }
    }
}
