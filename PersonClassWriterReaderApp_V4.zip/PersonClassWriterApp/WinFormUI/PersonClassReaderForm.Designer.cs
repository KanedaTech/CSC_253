﻿
namespace WinFormUI
{
    partial class PersonClassReaderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usersLabel = new System.Windows.Forms.Label();
            this.userInfoListBox = new System.Windows.Forms.ListBox();
            this.readFileButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // usersLabel
            // 
            this.usersLabel.AutoSize = true;
            this.usersLabel.Location = new System.Drawing.Point(74, 9);
            this.usersLabel.Name = "usersLabel";
            this.usersLabel.Size = new System.Drawing.Size(125, 15);
            this.usersLabel.TabIndex = 0;
            this.usersLabel.Text = "Read User Information";
            // 
            // userInfoListBox
            // 
            this.userInfoListBox.FormattingEnabled = true;
            this.userInfoListBox.ItemHeight = 15;
            this.userInfoListBox.Location = new System.Drawing.Point(12, 38);
            this.userInfoListBox.Name = "userInfoListBox";
            this.userInfoListBox.Size = new System.Drawing.Size(255, 229);
            this.userInfoListBox.TabIndex = 1;
            // 
            // readFileButton
            // 
            this.readFileButton.Location = new System.Drawing.Point(12, 277);
            this.readFileButton.Name = "readFileButton";
            this.readFileButton.Size = new System.Drawing.Size(122, 50);
            this.readFileButton.TabIndex = 2;
            this.readFileButton.Text = "Read File";
            this.readFileButton.UseVisualStyleBackColor = true;
            this.readFileButton.Click += new System.EventHandler(this.readFileButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(140, 277);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(127, 50);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // PersonClassReaderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 339);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.readFileButton);
            this.Controls.Add(this.userInfoListBox);
            this.Controls.Add(this.usersLabel);
            this.Name = "PersonClassReaderForm";
            this.Text = "Person Class Reader Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label usersLabel;
        private System.Windows.Forms.ListBox userInfoListBox;
        private System.Windows.Forms.Button readFileButton;
        private System.Windows.Forms.Button exitButton;
    }
}