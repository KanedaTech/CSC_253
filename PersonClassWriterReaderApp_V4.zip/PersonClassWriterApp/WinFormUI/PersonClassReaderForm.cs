﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using PersonClassLibrary;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class PersonClassReaderForm : Form
    {
        public PersonClassReaderForm()
        {
            InitializeComponent();
        }
        //Execute this code when readFileButton is clicked in the form.
        private void readFileButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable message and assign it the value of the method call ReadUserInfoFile() from Reader class.
            //Reads from file and returns a message string.
            string message = Reader.ReadUserInfoFile();
            //Initialize a string List userInfo.
            List<string> userInfo = new List<string>();
            //Initialize string variable to hold a listHeader for the listBox.
            string listHeader = $"{"First Name"}{" | "}{ "Middle Name"}{" | "}{ "Last Name"}{" | "}{ "Age"}";
            //Initialize string variable to hold underline display for the listBox.
            string headerUnderline = "==============================================";
            //Add the listHeader to userInfo list.
            userInfo.Add(listHeader);
            //Add the headerUnderline to the userInfo list.
            userInfo.Add(headerUnderline);
            //Use foreach loop to iterate over people list created by ListBuilder class. Initialize PersonClass object person. 
            foreach(PersonClass person in ListBuilder.people)
            {
                //Initialize string variable user and assign it the value of a string comprised of all the properties of person object.
                string user = $"{person.FirstName}, {person.MiddleName}, {person.LastName}, {Convert.ToString(person.Age)}";
                //Add user string to userInfo List.
                userInfo.Add(user);
            }
            //Assign userInfoListBox.DataSource the userInfo List. Displays the contents of the userInfo List to the user inside the form.
            userInfoListBox.DataSource = userInfo;
            //Display message to the user that the file has been read.
            MessageBox.Show(message);
        }
        //Execute this code when the exitButton is clicked in the form.
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the application.
            Close();
        }
    }
}
