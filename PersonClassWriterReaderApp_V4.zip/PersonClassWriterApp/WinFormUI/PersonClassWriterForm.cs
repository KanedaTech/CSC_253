﻿/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using PersonClassLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class PersonClassWriterForm : Form
    {
        public PersonClassWriterForm()
        {
            InitializeComponent();
        }
        //Execute this code when submitButton is clicked in the form.
        private void submitButton_Click(object sender, EventArgs e)
        {
            //Initialize variables and assign them the values of the user's input from textboxes.
            string firstName = firstNameTextBox.Text.Trim();
            string middleName = middleNameTextBox.Text.Trim();
            string lastName = lastNameTextBox.Text.Trim();
            int age = Convert.ToInt32(ageTextBox.Text.Trim());
            //Call BuildList method and pass parameters to create the list.
            ListBuilder.BuildList(firstName, middleName, lastName, age);
        }
        //Execute this code when the writeFileButton is clicked in the form.
        private void writeFileButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable message and assign it the WriteToFile() method call from FileWriter class.
            string message = FileWriter.WriteToFile();
            //Display a message to the user that the file has been created.
            MessageBox.Show(message);
        }
        //Execute this code when the exitButton is clicked in the form.
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the application.
            Close();
        }
    }
}
