/**
* 09-24-21
* CSC 253
* Adrian Gorum
* Application allows user to choose between two forms. One form will allow the user to fill in user information and save that information to a file called UserInformation.csv.
* The other form will allow the user to read the UserInformation.csv file and display it's contents to the user. 
*/
using System;
using System.Windows.Forms;

namespace WinFormUI
{
    class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Create new form object DescForm. Instance of Decision Form.
            DecisionForm DescForm = new();
            //Run Decision Form.
            Application.Run(DescForm);
            //If else conditional statement checks if bool statement is true or false.
            if (DescForm.isWriterChoice)
            {
                //Run PersonClassWriterForm.
                Application.Run(new PersonClassWriterForm());
            }
            else if (!DescForm.isWriterChoice)
            {
                //Run PersonClassReaderForm.
                Application.Run(new PersonClassReaderForm());
            }
        }
    }
}
