﻿using System;
using System.IO;

namespace RandomNumWriteLibrary
{
    public static class Writer
    {
        public static string WriteToFile(string numbers)
        {
            //Use a try and catch to handle exceptions.
            try
            {
                //Declare a StreamWriter variable.
                StreamWriter outputFile;

                //Create a file and get a StreamWriter object.
                outputFile = File.CreateText("RandomNumbers.txt");

                string[] subs = numbers.Split();

                foreach (string sub in subs)
                {
                    //Write the friend's name to the file.
                    outputFile.WriteLine(sub);
                }  
                
                //Close the file.
                outputFile.Close();
                //Initialize a string variable and assign it a message for the user that the name was written.
                string message = "The numbers have been written.";
                //Return message string variable
                return message;

            }
            catch (Exception ex)
            {
                //Initialize a string variable and assign it a message for the user that an error occured.
                string message = Convert.ToString(ex);
                //Return message string variable.
                return message;
            }

        }
         

    }
}
