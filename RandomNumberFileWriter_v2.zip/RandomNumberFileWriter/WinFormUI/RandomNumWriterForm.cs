﻿using System;
using RandomNumWriteLibrary;
using System.Windows.Forms;
using System.Collections.Generic;

namespace WinFormUI
{
    public partial class RandomNumWriterForm : Form
    {
        public RandomNumWriterForm()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            int num = 0;
            var numList = new List<int>();
            int instances = Convert.ToInt32(UserInputTextBox.Text.Trim());
            Random random = new Random();

            for (int i = 0; i < instances; i++)
            {
                num = random.Next(0, 100);

                numList.Add(num);
            }

            string message = Writer.WriteFile(numList);

            MessageBox.Show(message);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
