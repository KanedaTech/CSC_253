﻿
namespace WinFormUI
{
    partial class WordCounterForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnterStringLabel = new System.Windows.Forms.Label();
            this.StringTextBox = new System.Windows.Forms.TextBox();
            this.CountWordsButton = new System.Windows.Forms.Button();
            this.NumberOfWordsLabel = new System.Windows.Forms.Label();
            this.NumberLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EnterStringLabel
            // 
            this.EnterStringLabel.AutoSize = true;
            this.EnterStringLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EnterStringLabel.Location = new System.Drawing.Point(12, 32);
            this.EnterStringLabel.Name = "EnterStringLabel";
            this.EnterStringLabel.Size = new System.Drawing.Size(108, 21);
            this.EnterStringLabel.TabIndex = 0;
            this.EnterStringLabel.Text = "Enter String: ";
            // 
            // StringTextBox
            // 
            this.StringTextBox.Location = new System.Drawing.Point(114, 34);
            this.StringTextBox.Name = "StringTextBox";
            this.StringTextBox.Size = new System.Drawing.Size(444, 23);
            this.StringTextBox.TabIndex = 1;
            // 
            // CountWordsButton
            // 
            this.CountWordsButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CountWordsButton.Location = new System.Drawing.Point(72, 109);
            this.CountWordsButton.Name = "CountWordsButton";
            this.CountWordsButton.Size = new System.Drawing.Size(129, 32);
            this.CountWordsButton.TabIndex = 2;
            this.CountWordsButton.Text = "Count Words";
            this.CountWordsButton.UseVisualStyleBackColor = true;
            this.CountWordsButton.Click += new System.EventHandler(this.CountWordsButton_Click);
            // 
            // NumberOfWordsLabel
            // 
            this.NumberOfWordsLabel.AutoSize = true;
            this.NumberOfWordsLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NumberOfWordsLabel.Location = new System.Drawing.Point(325, 115);
            this.NumberOfWordsLabel.Name = "NumberOfWordsLabel";
            this.NumberOfWordsLabel.Size = new System.Drawing.Size(154, 21);
            this.NumberOfWordsLabel.TabIndex = 3;
            this.NumberOfWordsLabel.Text = "Number of Words: ";
            // 
            // NumberLabel
            // 
            this.NumberLabel.AutoSize = true;
            this.NumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NumberLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NumberLabel.Location = new System.Drawing.Point(475, 115);
            this.NumberLabel.MinimumSize = new System.Drawing.Size(40, 20);
            this.NumberLabel.Name = "NumberLabel";
            this.NumberLabel.Size = new System.Drawing.Size(40, 23);
            this.NumberLabel.TabIndex = 4;
            this.NumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // WordCounterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 159);
            this.Controls.Add(this.NumberLabel);
            this.Controls.Add(this.NumberOfWordsLabel);
            this.Controls.Add(this.CountWordsButton);
            this.Controls.Add(this.StringTextBox);
            this.Controls.Add(this.EnterStringLabel);
            this.Name = "WordCounterForm";
            this.Text = "Word Counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label EnterStringLabel;
        private System.Windows.Forms.TextBox StringTextBox;
        private System.Windows.Forms.Button CountWordsButton;
        private System.Windows.Forms.Label NumberOfWordsLabel;
        private System.Windows.Forms.Label NumberLabel;
    }
}

