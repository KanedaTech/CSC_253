﻿using System;
using WordCounterLibrary;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class WordCounterForm : Form
    {
        public WordCounterForm()
        {
            InitializeComponent();
        }
        //When CountWordsButton is clicked initialize string variable named words and give it the value of the text in the StringTextBox.
        private void CountWordsButton_Click(object sender, EventArgs e)
        {
            //Initialize string variable words. Assign text from StringTextBox.
            string words = StringTextBox.Text.Trim();
            //Assign NumberLabel.Text the value of the method call from the WordCounterLibrary method CountWords(). 
            NumberLabel.Text = Convert.ToString(WordCount.CountWords(words));
        }
    }
}
