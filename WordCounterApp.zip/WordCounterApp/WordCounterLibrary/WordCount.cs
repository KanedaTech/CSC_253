﻿namespace WordCounterLibrary
{
    public class WordCount
    {
        //Create a method that takes one string argument. Create and array within the mothod to hold all of the strings and split them by their empty space.
        public static int CountWords(string words)
        {
            //Initialize string array and assign it the value of the passed string argument words. Use method call Split() to separate the words in the string that was passed.
            string[] wordsArray = words.Split(' ');
            //Return the length of the array.
            return wordsArray.Length;
        }
    }
}
